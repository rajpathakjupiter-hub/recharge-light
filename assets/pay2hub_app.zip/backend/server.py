from fastapi import FastAPI, APIRouter, HTTPException, Depends
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from fastapi.responses import FileResponse
from dotenv import load_dotenv
from starlette.middleware.cors import CORSMiddleware
from motor.motor_asyncio import AsyncIOMotorClient
import os
import logging
from pathlib import Path
from pydantic import BaseModel, Field
from typing import List, Optional
import uuid
from datetime import datetime
import httpx

ROOT_DIR = Path(__file__).parent
load_dotenv(ROOT_DIR / '.env')

# Logo/Assets directory
ASSETS_DIR = ROOT_DIR.parent / "frontend" / "assets" / "images"

# MongoDB connection
mongo_url = os.environ['MONGO_URL']
client = AsyncIOMotorClient(mongo_url)
db = client[os.environ['DB_NAME']]

# Pay2Hub API Base URL
PAY2HUB_BASE_URL = "https://pay2hub.in/api"

# Create the main app without a prefix
app = FastAPI()

# Create a router with the /api prefix
api_router = APIRouter(prefix="/api")

security = HTTPBearer(auto_error=False)

# Models
class SendOTPRequest(BaseModel):
    mobile: str

class VerifyOTPRequest(BaseModel):
    mobile: str
    otp: str

class RegisterRequest(BaseModel):
    mobile: str
    name: str
    otp: str

class RechargeRequest(BaseModel):
    mobile_number: str
    operator_code: str
    amount: int


# Logo download endpoints (no auth required)
@api_router.get("/logo/icon")
async def get_icon():
    icon_path = ASSETS_DIR / "icon.png"
    if icon_path.exists():
        return FileResponse(str(icon_path), media_type="image/png", headers={"Content-Disposition": "inline"})
    raise HTTPException(status_code=404, detail="Icon not found")

@api_router.get("/logo/adaptive")
async def get_adaptive_icon():
    icon_path = ASSETS_DIR / "adaptive-icon.png"
    if icon_path.exists():
        return FileResponse(str(icon_path), media_type="image/png", headers={"Content-Disposition": "inline"})
    raise HTTPException(status_code=404, detail="Icon not found")

@api_router.get("/logo/logo")
async def get_logo():
    icon_path = ASSETS_DIR / "pay2hub-logo.png"
    if icon_path.exists():
        return FileResponse(str(icon_path), media_type="image/png", headers={"Content-Disposition": "inline"})
    raise HTTPException(status_code=404, detail="Logo not found")


class UserSession(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    user_id: str
    mobile: str
    name: str
    token: str
    api_key: str
    wallet_balance: float = 0.0
    commission_percent: float = 0.0
    created_at: datetime = Field(default_factory=datetime.utcnow)

# Helper to get current user from token
async def get_current_user(credentials: HTTPAuthorizationCredentials = Depends(security)):
    if not credentials:
        raise HTTPException(status_code=401, detail="Not authenticated")
    
    token = credentials.credentials
    
    # First try exact token match
    session = await db.sessions.find_one({"token": token})
    if session:
        return session
    
    # Try to decode JWT and find session by user_id
    try:
        import jwt
        payload = jwt.decode(token, options={"verify_signature": False, "verify_exp": False})
        user_id = payload.get("user_id")
        if user_id:
            session = await db.sessions.find_one({"user_id": user_id})
            if session:
                # Update stored token
                await db.sessions.update_one(
                    {"user_id": user_id},
                    {"$set": {"token": token}}
                )
                return session
    except Exception:
        pass
    
    raise HTTPException(status_code=401, detail="Invalid or expired token")

@api_router.post("/auth/send-otp")
async def send_otp(request: SendOTPRequest):
    try:
        # Call pay2hub.in API directly
        async with httpx.AsyncClient() as client:
            response = await client.post(
                f"{PAY2HUB_BASE_URL}/auth/send-otp",
                json={"mobile": request.mobile}
            )
            
            if response.status_code == 200:
                data = response.json()
                return data
            else:
                raise HTTPException(status_code=response.status_code, detail=response.text)
    except Exception as e:
        logging.error(f"Send OTP error: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@api_router.post("/auth/verify-otp")
async def verify_otp(request: VerifyOTPRequest):
    try:
        # Call pay2hub.in API directly to get REAL token and API key
        async with httpx.AsyncClient() as client:
            response = await client.post(
                f"{PAY2HUB_BASE_URL}/auth/verify-otp",
                json={"mobile": request.mobile, "otp": request.otp}
            )
            
            if response.status_code == 200:
                data = response.json()
                
                # pay2hub.in returns: token, user (with api_key), is_new_user
                if "token" in data and "user" in data:
                    token = data["token"]
                    user = data["user"]
                    
                    # Save user to our DB
                    user_data = {
                        "id": user.get("id"),
                        "mobile": request.mobile,
                        "name": user.get("name", ""),
                        "api_key": user.get("api_key", ""),
                        "wallet_balance": user.get("wallet_balance", 0),
                        "commission_percent": user.get("commission_percent", 0),
                        "created_at": datetime.utcnow()
                    }
                    
                    await db.users.update_one(
                        {"mobile": request.mobile},
                        {"$set": user_data},
                        upsert=True
                    )
                    
                    # Save session
                    session = {
                        "id": str(uuid.uuid4()),
                        "user_id": user.get("id"),
                        "mobile": request.mobile,
                        "name": user.get("name", ""),
                        "token": token,
                        "api_key": user.get("api_key", ""),
                        "wallet_balance": user.get("wallet_balance", 0),
                        "commission_percent": user.get("commission_percent", 0),
                        "created_at": datetime.utcnow()
                    }
                    
                    await db.sessions.update_one(
                        {"mobile": request.mobile},
                        {"$set": session},
                        upsert=True
                    )
                    
                    logging.info(f"User logged in: {request.mobile}, API key: {user.get('api_key', 'none')}")
                    
                    return data
                else:
                    # New user - needs registration
                    return data
            else:
                raise HTTPException(status_code=response.status_code, detail=response.text)
                
    except Exception as e:
        logging.error(f"Verify OTP error: {e}")
        raise HTTPException(status_code=400, detail=str(e))

@api_router.post("/auth/register")
async def register(request: RegisterRequest):
    try:
        # Call pay2hub.in API for registration
        async with httpx.AsyncClient() as client:
            response = await client.post(
                f"{PAY2HUB_BASE_URL}/auth/register",
                json={
                    "mobile": request.mobile,
                    "name": request.name,
                    "otp": request.otp
                }
            )
            
            if response.status_code == 200:
                data = response.json()
                
                # Save user to our DB
                if "token" in data and "user" in data:
                    token = data["token"]
                    user = data["user"]
                    
                    user_data = {
                        "id": user.get("id"),
                        "mobile": request.mobile,
                        "name": request.name,
                        "api_key": user.get("api_key", ""),
                        "wallet_balance": user.get("wallet_balance", 0),
                        "commission_percent": user.get("commission_percent", 0),
                        "created_at": datetime.utcnow()
                    }
                    
                    await db.users.update_one(
                        {"mobile": request.mobile},
                        {"$set": user_data},
                        upsert=True
                    )
                    
                    # Save session
                    session = {
                        "id": str(uuid.uuid4()),
                        "user_id": user.get("id"),
                        "mobile": request.mobile,
                        "name": request.name,
                        "token": token,
                        "api_key": user.get("api_key", ""),
                        "wallet_balance": user.get("wallet_balance", 0),
                        "commission_percent": user.get("commission_percent", 0),
                        "created_at": datetime.utcnow()
                    }
                    
                    await db.sessions.update_one(
                        {"mobile": request.mobile},
                        {"$set": session},
                        upsert=True
                    )
                    
                    logging.info(f"New user registered: {request.mobile}, API key: {user.get('api_key', 'none')}")
                    
                    return data
            else:
                raise HTTPException(status_code=response.status_code, detail=response.text)
                
    except Exception as e:
        logging.error(f"Register error: {e}")
        raise HTTPException(status_code=400, detail=str(e))

@api_router.get("/auth/me")
async def get_me(session = Depends(get_current_user)):
    try:
        async with httpx.AsyncClient() as client:
            response = await client.get(
                f"{PAY2HUB_BASE_URL}/auth/me",
                headers={"Authorization": f"Bearer {session['token']}"}
            )
            return response.json()
    except Exception as e:
        logging.error(f"Get me error: {e}")
        raise HTTPException(status_code=500, detail=str(e))

# Balance API
@api_router.get("/balance")
async def get_balance(session = Depends(get_current_user)):
    try:
        # If API key exists, fetch from external API
        if session.get("api_key"):
            async with httpx.AsyncClient() as client:
                response = await client.get(
                    f"{PAY2HUB_BASE_URL}/external/balance",
                    params={"api_key": session["api_key"]}
                )
                data = response.json()
                
                # Update session balance
                if "balance" in data:
                    await db.sessions.update_one(
                        {"token": session["token"]},
                        {"$set": {"wallet_balance": data["balance"]}}
                    )
                
                return data
        else:
            # Return balance from session/stored data
            return {
                "balance": session.get("wallet_balance", 0),
                "total_balance": session.get("wallet_balance", 0),
                "hold_amount": 0,
                "name": session.get("name", "")
            }
    except Exception as e:
        logging.error(f"Get balance error: {e}")
        raise HTTPException(status_code=500, detail=str(e))

# Operators API
@api_router.get("/operators")
async def get_operators(session = Depends(get_current_user)):
    try:
        # If API key exists, fetch from external API
        if session.get("api_key"):
            async with httpx.AsyncClient() as client:
                response = await client.get(
                    f"{PAY2HUB_BASE_URL}/external/operators",
                    params={"api_key": session["api_key"]}
                )
                return response.json()
        else:
            # Return default operators
            return {
                "status": "success",
                "your_commission_rate": session.get("commission_percent", 2.0),
                "prepaid": [
                    {"code": "jio", "name": "Jio", "commission": 2.0},
                    {"code": "airtel", "name": "Airtel", "commission": 2.0},
                    {"code": "vi", "name": "Vi", "commission": 2.0},
                    {"code": "bsnl", "name": "BSNL", "commission": 2.0}
                ],
                "postpaid": [],
                "dth": [
                    {"code": "tatasky", "name": "Tata Sky", "commission": 2.0},
                    {"code": "airteldth", "name": "Airtel DTH", "commission": 2.0},
                    {"code": "dishtv", "name": "Dish TV", "commission": 2.0},
                    {"code": "d2h", "name": "D2H", "commission": 2.0},
                    {"code": "sundirect", "name": "Sun Direct", "commission": 2.0}
                ]
            }
    except Exception as e:
        logging.error(f"Get operators error: {e}")
        raise HTTPException(status_code=500, detail=str(e))

# Plans API - Fetch from external API
@api_router.get("/plans/{operator_code}")
async def get_plans(operator_code: str, circle: str = "del", session = Depends(get_current_user)):
    try:
        # If no api_key, return demo plans
        if not session.get("api_key"):
            return {
                "status": "success",
                "operator": operator_code,
                "circle": circle,
                "categories": ["Popular", "Data", "Talktime", "Unlimited"],
                "plans": [
                    {
                        "amount": 199,
                        "validity": "28 days",
                        "data": "2GB/day",
                        "voice": "Unlimited",
                        "sms": "100/day",
                        "description": "2GB data per day + Unlimited calls",
                        "category": "Popular"
                    },
                    {
                        "amount": 299,
                        "validity": "28 days",
                        "data": "1.5GB/day",
                        "voice": "Unlimited",
                        "sms": "100/day",
                        "description": "1.5GB data per day + Unlimited calls",
                        "category": "Data"
                    },
                    {
                        "amount": 479,
                        "validity": "56 days",
                        "data": "1.5GB/day",
                        "voice": "Unlimited",
                        "sms": "100/day",
                        "description": "1.5GB data per day for 56 days",
                        "category": "Popular"
                    },
                    {
                        "amount": 719,
                        "validity": "84 days",
                        "data": "1.5GB/day",
                        "voice": "Unlimited",
                        "sms": "100/day",
                        "description": "1.5GB data per day for 84 days",
                        "category": "Unlimited"
                    },
                    {
                        "amount": 3099,
                        "validity": "365 days",
                        "data": "2GB/day",
                        "voice": "Unlimited",
                        "sms": "100/day",
                        "description": "Annual plan with 2GB daily data",
                        "category": "Unlimited"
                    }
                ]
            }
        
        async with httpx.AsyncClient(timeout=30.0) as client:
            response = await client.get(
                f"{PAY2HUB_BASE_URL}/external/plans",
                params={
                    "api_key": session["api_key"],
                    "operator": operator_code,
                    "circle": circle
                }
            )
            if response.status_code == 200:
                return response.json()
            return {"status": "error", "categories": [], "plans": []}
    except Exception as e:
        logging.error(f"Get plans error: {e}")
        # Fallback to demo plans
        return {
            "status": "success",
            "operator": operator_code,
            "circle": circle,
            "categories": ["Popular", "Data"],
            "plans": [
                {
                    "amount": 199,
                    "validity": "28 days",
                    "data": "2GB/day",
                    "voice": "Unlimited",
                    "sms": "100/day",
                    "description": "2GB data per day + Unlimited calls",
                    "category": "Popular"
                },
                {
                    "amount": 299,
                    "validity": "28 days",
                    "data": "1.5GB/day",
                    "voice": "Unlimited",
                    "sms": "100/day",
                    "description": "1.5GB data per day + Unlimited calls",
                    "category": "Data"
                }
            ]
        }

# Circle codes list
@api_router.get("/circles")
async def get_circles():
    return {
        "circles": [
            {"code": "del", "name": "Delhi NCR"},
            {"code": "mum", "name": "Mumbai"},
            {"code": "kar", "name": "Karnataka"},
            {"code": "tn", "name": "Tamil Nadu"},
            {"code": "mah", "name": "Maharashtra"},
            {"code": "guj", "name": "Gujarat"},
            {"code": "raj", "name": "Rajasthan"},
            {"code": "pun", "name": "Punjab"},
            {"code": "har", "name": "Haryana"},
            {"code": "upw", "name": "UP West"},
            {"code": "upe", "name": "UP East"},
            {"code": "br", "name": "Bihar"},
            {"code": "wb", "name": "West Bengal"},
            {"code": "ker", "name": "Kerala"},
            {"code": "ap", "name": "Andhra Pradesh"},
            {"code": "mp", "name": "Madhya Pradesh"},
            {"code": "che", "name": "Chennai"},
            {"code": "kol", "name": "Kolkata"},
            {"code": "ori", "name": "Orissa"},
            {"code": "jh", "name": "Jharkhand"},
            {"code": "asm", "name": "Assam"},
            {"code": "ne", "name": "North East"},
        ]
    }

# Recharge API
@api_router.post("/recharge")
async def do_recharge(request: RechargeRequest, session = Depends(get_current_user)):
    order_id = f"ORD{datetime.now().strftime('%Y%m%d%H%M%S')}{uuid.uuid4().hex[:6].upper()}"
    
    try:
        async with httpx.AsyncClient(timeout=120.0) as client:
            response = await client.get(
                f"{PAY2HUB_BASE_URL}/external/recharge",
                params={
                    "api_key": session["api_key"],
                    "mobile_number": request.mobile_number,
                    "operator_code": request.operator_code,
                    "amount": request.amount,
                    "request_order_id": order_id
                }
            )
            data = response.json()
            
            # Store recharge in our DB
            recharge_record = {
                "id": str(uuid.uuid4()),
                "user_id": session["user_id"],
                "mobile": session["mobile"],
                "order_id": order_id,
                "mobile_number": request.mobile_number,
                "operator_code": request.operator_code,
                "amount": request.amount,
                "status": data.get("status", "pending"),
                "transaction_id": data.get("transaction_id", ""),
                "operator_ref": data.get("operator_ref", ""),
                "commission": data.get("commission", 0),
                "balance": data.get("balance", 0),
                "message": data.get("message", ""),
                "created_at": datetime.utcnow()
            }
            
            await db.recharges.insert_one(recharge_record)
            
            # Always return with order_id
            data["order_id"] = order_id
            return data
            
    except Exception as e:
        logging.error(f"Recharge error: {e}")
        # Even on error, return pending status so user can check later
        recharge_record = {
            "id": str(uuid.uuid4()),
            "user_id": session["user_id"],
            "mobile": session["mobile"],
            "order_id": order_id,
            "mobile_number": request.mobile_number,
            "operator_code": request.operator_code,
            "amount": request.amount,
            "status": "pending",
            "transaction_id": "",
            "operator_ref": "",
            "commission": 0,
            "balance": 0,
            "message": "Processing your recharge...",
            "created_at": datetime.utcnow()
        }
        await db.recharges.insert_one(recharge_record)
        
        return {
            "status": "pending",
            "order_id": order_id,
            "message": "Recharge submitted, checking status...",
            "transaction_id": "",
            "commission": 0
        }

# Status API
@api_router.get("/status/{order_id}")
async def check_status(order_id: str, session = Depends(get_current_user)):
    try:
        # First try external API
        async with httpx.AsyncClient(timeout=120.0) as client:
            response = await client.get(
                f"{PAY2HUB_BASE_URL}/external/status",
                params={
                    "api_key": session["api_key"],
                    "order_id": order_id
                }
            )
            data = response.json()
            
            # If external API returns valid status, update local DB and return
            if data.get("status") and data.get("status") != "not_found":
                # Update local record
                await db.recharges.update_one(
                    {"order_id": order_id},
                    {"$set": {
                        "status": data.get("status"),
                        "transaction_id": data.get("transaction_id", ""),
                        "operator_ref": data.get("operator_ref", ""),
                        "commission": data.get("commission", 0),
                        "message": data.get("message", "")
                    }}
                )
                return data
            
            # If not found in external API, check local DB
            local_record = await db.recharges.find_one({"order_id": order_id})
            if local_record:
                return {
                    "status": local_record.get("status", "pending"),
                    "order_id": order_id,
                    "transaction_id": local_record.get("transaction_id", ""),
                    "operator_ref": local_record.get("operator_ref", ""),
                    "commission": local_record.get("commission", 0),
                    "message": local_record.get("message", "Processing..."),
                    "amount": local_record.get("amount", 0),
                    "mobile_number": local_record.get("mobile_number", "")
                }
            
            # Return pending if nothing found
            return {
                "status": "pending",
                "order_id": order_id,
                "message": "Checking status...",
                "transaction_id": "",
                "commission": 0
            }
            
    except Exception as e:
        logging.error(f"Check status error: {e}")
        # On error, check local DB
        try:
            local_record = await db.recharges.find_one({"order_id": order_id})
            if local_record:
                return {
                    "status": local_record.get("status", "pending"),
                    "order_id": order_id,
                    "transaction_id": local_record.get("transaction_id", ""),
                    "commission": local_record.get("commission", 0),
                    "message": local_record.get("message", "Processing...")
                }
        except:
            pass
        return {
            "status": "pending",
            "order_id": order_id,
            "message": "Checking status...",
            "transaction_id": "",
            "commission": 0
        }

# Transaction History API
@api_router.get("/transactions")
async def get_transactions(limit: int = 50, type: str = "all", session = Depends(get_current_user)):
    try:
        # If no api_key, return demo transactions
        if not session.get("api_key"):
            demo_transactions = [
                {
                    "transaction_id": "TXN001",
                    "type": "MOBILE_RECHARGE",
                    "mobile_number": "9876543210",
                    "operator": "Jio",
                    "amount": 199,
                    "commission": 3.98,
                    "status": "success",
                    "created_at": "2026-02-15 14:30:00"
                },
                {
                    "transaction_id": "TXN002",
                    "type": "DTH_RECHARGE",
                    "mobile_number": "1234567890",
                    "operator": "Tata Sky",
                    "amount": 350,
                    "commission": 7.00,
                    "status": "success",
                    "created_at": "2026-02-14 10:15:00"
                },
                {
                    "transaction_id": "TXN003",
                    "type": "MOBILE_RECHARGE",
                    "mobile_number": "8765432109",
                    "operator": "Airtel",
                    "amount": 299,
                    "commission": 5.98,
                    "status": "success",
                    "created_at": "2026-02-13 16:45:00"
                }
            ]
            return {"transactions": demo_transactions}
        
        async with httpx.AsyncClient() as client:
            response = await client.get(
                f"{PAY2HUB_BASE_URL}/external/transactions",
                params={
                    "api_key": session["api_key"],
                    "limit": limit,
                    "type": type
                }
            )
            return response.json()
    except Exception as e:
        logging.error(f"Get transactions error: {e}")
        # Return demo data on error
        return {
            "transactions": [
                {
                    "transaction_id": "TXN001",
                    "type": "MOBILE_RECHARGE",
                    "mobile_number": "9876543210",
                    "operator": "Jio",
                    "amount": 199,
                    "commission": 3.98,
                    "status": "success",
                    "created_at": "2026-02-15 14:30:00"
                }
            ]
        }

# Recharge History API
@api_router.get("/recharge/history")
async def get_recharge_history(limit: int = 50, status: Optional[str] = None, session = Depends(get_current_user)):
    try:
        params = {
            "api_key": session["api_key"],
            "limit": limit
        }
        if status:
            params["status"] = status
            
        async with httpx.AsyncClient() as client:
            response = await client.get(
                f"{PAY2HUB_BASE_URL}/external/recharge/history",
                params=params
            )
            return response.json()
    except Exception as e:
        logging.error(f"Get recharge history error: {e}")
        raise HTTPException(status_code=500, detail=str(e))

# Margin API (retailer commission)
@api_router.get("/margin")
async def get_margin(operator_code: Optional[str] = None, session = Depends(get_current_user)):
    try:
        # If no api_key, return demo margins
        if not session.get("api_key"):
            demo_margins = [
                {"operator_code": "jio", "operator_name": "Jio", "type": "prepaid", "margin_percent": 2.0},
                {"operator_code": "airtel", "operator_name": "Airtel", "type": "prepaid", "margin_percent": 2.0},
                {"operator_code": "vi", "operator_name": "Vi (Vodafone Idea)", "type": "prepaid", "margin_percent": 2.0},
                {"operator_code": "bsnl", "operator_name": "BSNL", "type": "prepaid", "margin_percent": 2.5},
                {"operator_code": "tatasky", "operator_name": "Tata Sky", "type": "dth", "margin_percent": 2.0},
                {"operator_code": "airteldth", "operator_name": "Airtel DTH", "type": "dth", "margin_percent": 2.0},
                {"operator_code": "dishtv", "operator_name": "Dish TV", "type": "dth", "margin_percent": 1.8},
                {"operator_code": "d2h", "operator_name": "D2H", "type": "dth", "margin_percent": 1.8},
                {"operator_code": "sundirect", "operator_name": "Sun Direct", "type": "dth", "margin_percent": 2.0}
            ]
            
            if operator_code:
                filtered = [m for m in demo_margins if m["operator_code"] == operator_code]
                return {"margins": filtered}
            return {"margins": demo_margins}
        
        params = {"api_key": session["api_key"]}
        if operator_code:
            params["operator_code"] = operator_code
            
        async with httpx.AsyncClient() as client:
            response = await client.get(
                f"{PAY2HUB_BASE_URL}/external/margin",
                params=params
            )
            return response.json()
    except Exception as e:
        logging.error(f"Get margin error: {e}")
        # Return demo data on error
        return {
            "margins": [
                {"operator_code": "jio", "operator_name": "Jio", "type": "prepaid", "margin_percent": 2.0},
                {"operator_code": "airtel", "operator_name": "Airtel", "type": "prepaid", "margin_percent": 2.0},
                {"operator_code": "tatasky", "operator_name": "Tata Sky", "type": "dth", "margin_percent": 2.0}
            ]
        }

# Commission API
@api_router.get("/commission")
async def get_commission(session = Depends(get_current_user)):
    try:
        async with httpx.AsyncClient() as client:
            response = await client.get(
                f"{PAY2HUB_BASE_URL}/external/commission",
                params={"api_key": session["api_key"]}
            )
            return response.json()
    except Exception as e:
        logging.error(f"Get commission error: {e}")
        raise HTTPException(status_code=500, detail=str(e))

# Create Payment Order (UPI)
@api_router.post("/payment/create")
async def create_payment(amount: int, redirect_url: Optional[str] = None, session = Depends(get_current_user)):
    try:
        payload = {
            "api_key": session["api_key"],
            "amount": amount
        }
        if redirect_url:
            payload["redirect_url"] = redirect_url
            
        async with httpx.AsyncClient() as client:
            response = await client.post(
                f"{PAY2HUB_BASE_URL}/external/payment/create",
                json=payload
            )
            return response.json()
    except Exception as e:
        logging.error(f"Create payment error: {e}")
        raise HTTPException(status_code=500, detail=str(e))

# Check Payment Status
@api_router.get("/payment/status/{order_id}")
async def check_payment_status(order_id: str, session = Depends(get_current_user)):
    try:
        async with httpx.AsyncClient(timeout=30.0) as client:
            response = await client.get(
                f"{PAY2HUB_BASE_URL}/external/payment/status",
                params={
                    "api_key": session["api_key"],
                    "order_id": order_id
                }
            )
            
            # Check if response is successful
            if response.status_code >= 500:
                logging.warning(f"Payment status API returned {response.status_code} for order {order_id}")
                return {
                    "payment_status": "pending",
                    "order_id": order_id,
                    "message": "Checking payment status..."
                }
            
            try:
                data = response.json()
                return data
            except Exception:
                return {
                    "payment_status": "pending",
                    "order_id": order_id,
                    "message": "Checking payment status..."
                }
    except Exception as e:
        logging.error(f"Check payment status error: {e}")
        # Return pending status instead of error - don't break the polling
        return {
            "payment_status": "pending",
            "order_id": order_id,
            "message": "Checking payment status..."
        }

# Wallet History API
@api_router.get("/wallet-history")
async def get_wallet_history(limit: int = 50, session = Depends(get_current_user)):
    try:
        async with httpx.AsyncClient() as client:
            response = await client.get(
                f"{PAY2HUB_BASE_URL}/user/wallet-history",
                params={"limit": limit},
                headers={"Authorization": f"Bearer {session['token']}"}
            )
            return response.json()
    except Exception as e:
        logging.error(f"Get wallet history error: {e}")
        raise HTTPException(status_code=500, detail=str(e))

# Session info API
@api_router.get("/session")
async def get_session_info(session = Depends(get_current_user)):
    return {
        "user_id": session["user_id"],
        "mobile": session["mobile"],
        "name": session["name"],
        "wallet_balance": session["wallet_balance"],
        "commission_percent": session["commission_percent"],
        "api_key": session.get("api_key", "")
    }

# Generate API Key (internal use only - called after login/register)
async def auto_generate_api_key(token: str, mobile: str):
    """Automatically generate API key after login/registration using pay2hub.in"""
    try:
        async with httpx.AsyncClient() as client:
            response = await client.post(
                f"{PAY2HUB_BASE_URL}/user/regenerate-key",  # Correct endpoint from docs
                headers={"Authorization": f"Bearer {token}"}
            )
            
            if response.status_code == 200:
                data = response.json()
                
                # If API key generated successfully, update session and user
                if data.get("api_key"):
                    await db.sessions.update_one(
                        {"token": token},
                        {"$set": {"api_key": data["api_key"]}}
                    )
                    await db.users.update_one(
                        {"mobile": mobile},
                        {"$set": {"api_key": data["api_key"]}}
                    )
                    logging.info(f"API key auto-generated for {mobile}")
                    return data["api_key"]
            else:
                logging.warning(f"API key generation failed: {response.status_code} - {response.text}")
    except Exception as e:
        logging.error(f"Auto generate API key error: {e}")
    return None

# Gift Card - Get Brands
@api_router.get("/giftcards/brands")
async def get_giftcard_brands(category: Optional[str] = None, session = Depends(get_current_user)):
    try:
        params = {"api_key": session["api_key"]}
        if category:
            params["category"] = category
        async with httpx.AsyncClient(timeout=30.0) as client:
            response = await client.get(
                f"{PAY2HUB_BASE_URL}/external/giftcards/brands",
                params=params
            )
            return response.json()
    except Exception as e:
        logging.error(f"Get giftcard brands error: {e}")
        raise HTTPException(status_code=500, detail=str(e))

# Gift Card - Get Commission
@api_router.get("/giftcards/commission")
async def get_giftcard_commission(brand_id: Optional[str] = None, session = Depends(get_current_user)):
    try:
        params = {"api_key": session["api_key"]}
        if brand_id:
            params["brand_id"] = brand_id
        async with httpx.AsyncClient(timeout=30.0) as client:
            response = await client.get(
                f"{PAY2HUB_BASE_URL}/external/giftcards/commission",
                params=params
            )
            return response.json()
    except Exception as e:
        logging.error(f"Get giftcard commission error: {e}")
        raise HTTPException(status_code=500, detail=str(e))

# Gift Card - Purchase
class GiftCardPurchaseRequest(BaseModel):
    brand_id: str
    amount: int

@api_router.post("/giftcards/purchase")
async def purchase_giftcard(request: GiftCardPurchaseRequest, session = Depends(get_current_user)):
    try:
        # Get balance BEFORE purchase
        balance_before = None
        try:
            async with httpx.AsyncClient(timeout=10.0) as bc:
                br = await bc.get(f"{PAY2HUB_BASE_URL}/external/balance", params={"api_key": session["api_key"]})
                if br.status_code == 200:
                    balance_before = br.json().get("balance")
        except Exception:
            pass

        async with httpx.AsyncClient(timeout=120.0) as client:
            response = await client.post(
                f"{PAY2HUB_BASE_URL}/external/giftcards/purchase",
                json={
                    "api_key": session["api_key"],
                    "brand_id": request.brand_id,
                    "amount": request.amount
                }
            )
            
            # Check if response returned an error HTTP status
            if response.status_code >= 500:
                # External API gave 500 - BUT it might have processed the purchase!
                # Check balance to determine if money was deducted
                actual_status = "pending"
                message = "Purchase is being processed. Please check history for status."
                
                if balance_before is not None:
                    try:
                        async with httpx.AsyncClient(timeout=10.0) as bc2:
                            br2 = await bc2.get(f"{PAY2HUB_BASE_URL}/external/balance", params={"api_key": session["api_key"]})
                            if br2.status_code == 200:
                                balance_after = br2.json().get("balance")
                                if balance_after is not None and balance_before - balance_after >= request.amount * 0.9:
                                    actual_status = "success"
                                    message = "Purchase processed successfully! Check gift card history for voucher details."
                    except Exception:
                        pass
                
                gc_record = {
                    "user_id": session["user_id"],
                    "mobile": session["mobile"],
                    "brand_id": request.brand_id,
                    "amount": request.amount,
                    "order_id": "",
                    "status": actual_status,
                    "commission": 0,
                    "message": message,
                    "brand_name": request.brand_id,
                    "created_at": datetime.utcnow()
                }
                await db.giftcard_orders.insert_one(gc_record)
                
                return {"status": actual_status, "message": message, "order_id": "", "commission": 0}
            
            if response.status_code >= 400:
                error_msg = "Purchase failed"
                try:
                    err_data = response.json()
                    error_msg = err_data.get("message", err_data.get("detail", "Purchase failed"))
                except Exception:
                    error_msg = f"Error ({response.status_code})"
                
                gc_record = {
                    "user_id": session["user_id"],
                    "mobile": session["mobile"],
                    "brand_id": request.brand_id,
                    "amount": request.amount,
                    "order_id": "",
                    "status": "failed",
                    "commission": 0,
                    "message": error_msg,
                    "brand_name": request.brand_id,
                    "created_at": datetime.utcnow()
                }
                await db.giftcard_orders.insert_one(gc_record)
                
                return {"status": "failed", "message": error_msg, "order_id": "", "commission": 0}
            
            data = response.json()
            
            # Check actual status in response
            resp_status = data.get("status", "pending")
            if resp_status == "error":
                resp_status = "failed"
            
            gc_record = {
                "user_id": session["user_id"],
                "mobile": session["mobile"],
                "brand_id": request.brand_id,
                "amount": request.amount,
                "order_id": data.get("order_id", ""),
                "status": resp_status,
                "commission": data.get("commission", 0),
                "voucher_code": data.get("voucher_code", ""),
                "voucher_pin": data.get("voucher_pin", ""),
                "expiry_date": "",
                "message": data.get("message", ""),
                "brand_name": data.get("brand_name", request.brand_id),
                "created_at": datetime.utcnow()
            }
            
            # Extract voucher details from vouchers array if available
            vouchers = data.get("vouchers", [])
            if vouchers and len(vouchers) > 0:
                v = vouchers[0]
                if not gc_record["voucher_code"]:
                    gc_record["voucher_code"] = v.get("code", "")
                if not gc_record["voucher_pin"]:
                    gc_record["voucher_pin"] = v.get("pin", "")
                gc_record["expiry_date"] = v.get("expiryDate", "")
                # Add to response data too
                data["expiry_date"] = v.get("expiryDate", "")
            
            await db.giftcard_orders.insert_one(gc_record)
            
            return data
    except Exception as e:
        logging.error(f"Purchase giftcard error: {e}")
        return {"status": "pending", "message": "Purchase is being processed. Please check history.", "order_id": "", "commission": 0}

# Gift Card - History
@api_router.get("/giftcards/history")
async def get_giftcard_history(limit: int = 20, session = Depends(get_current_user)):
    try:
        async with httpx.AsyncClient(timeout=30.0) as client:
            response = await client.get(
                f"{PAY2HUB_BASE_URL}/external/giftcards/history",
                params={
                    "api_key": session["api_key"],
                    "limit": limit
                }
            )
            if response.status_code == 200:
                try:
                    data = response.json()
                    if data.get("orders"):
                        return data
                except Exception:
                    pass
    except Exception as e:
        logging.error(f"Get giftcard history from API error: {e}")
    
    # Fallback to local DB
    try:
        orders = []
        cursor = db.giftcard_orders.find(
            {"user_id": session["user_id"]}
        ).sort("created_at", -1).limit(limit)
        async for order in cursor:
            orders.append({
                "id": str(order.get("_id", "")),
                "brand_name": order.get("brand_name", order.get("brand_id", "Gift Card")),
                "amount": order.get("amount", 0),
                "commission": order.get("commission", 0),
                "status": order.get("status", "pending"),
                "voucher_code": order.get("voucher_code", ""),
                "voucher_pin": order.get("voucher_pin", ""),
                "created_at": order.get("created_at", datetime.utcnow()).strftime("%Y-%m-%d %H:%M:%S") if isinstance(order.get("created_at"), datetime) else str(order.get("created_at", "")),
            })
        return {"status": "success", "orders": orders}
    except Exception as e:
        logging.error(f"Get giftcard history from DB error: {e}")
        return {"status": "success", "orders": []}
    except Exception as e:
        logging.error(f"Get giftcard history error: {e}")
        raise HTTPException(status_code=500, detail=str(e))

# Add your routes to the router instead of directly to app
@api_router.get("/")
async def root():
    return {"message": "Pay2Hub API Server Running"}

# Include the router in the main app
app.include_router(api_router)

app.add_middleware(
    CORSMiddleware,
    allow_credentials=True,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

@app.on_event("shutdown")
async def shutdown_db_client():
    client.close()
