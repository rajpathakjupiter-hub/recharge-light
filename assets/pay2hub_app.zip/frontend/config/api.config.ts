// API Configuration - Easy to Change
// File: config/api.config.ts

/**
 * API BASE URL CONFIGURATION
 * 
 * Production ke liye yahan base URL change karein
 * Phir APK rebuild karein
 */

// ====== MAIN CONFIGURATION - CHANGE HERE ======
export const API_CONFIG = {
  // Production API URL (Change this for production)
  BASE_URL: process.env.EXPO_PUBLIC_BACKEND_URL || 'https://pay2hub-dev.preview.emergentagent.com',
  
  // API Endpoints
  ENDPOINTS: {
    // Auth
    SEND_OTP: '/api/auth/send-otp',
    VERIFY_OTP: '/api/auth/verify-otp',
    REGISTER: '/api/auth/register',
    
    // User
    BALANCE: '/api/balance',
    PROFILE: '/api/session',
    
    // Transactions
    TRANSACTIONS: '/api/transactions',
    MARGIN: '/api/margin',
    
    // Operators
    OPERATORS: '/api/operators',
    PLANS: '/api/plans',
    
    // Recharge
    RECHARGE: '/api/recharge',
    STATUS: '/api/status',
    
    // Payment
    PAYMENT_CREATE: '/api/payment/create',
    PAYMENT_STATUS: '/api/payment/status',
    
    // Gift Cards
    GIFTCARDS: '/api/giftcards/brands',
    GIFTCARD_PURCHASE: '/api/giftcards/purchase',
    GIFTCARD_HISTORY: '/api/giftcards/history',
  },
  
  // Timeouts
  TIMEOUT: 30000, // 30 seconds
  
  // Retry Configuration
  RETRY_ATTEMPTS: 3,
  RETRY_DELAY: 1000, // 1 second
};

// ====== HELPER FUNCTIONS ======

/**
 * Get full API URL
 */
export const getApiUrl = (endpoint: string): string => {
  return `${API_CONFIG.BASE_URL}${endpoint}`;
};

/**
 * Get API URL with query params
 */
export const getApiUrlWithParams = (
  endpoint: string,
  params: Record<string, any>
): string => {
  const url = new URL(`${API_CONFIG.BASE_URL}${endpoint}`);
  Object.keys(params).forEach(key => {
    if (params[key] !== undefined && params[key] !== null) {
      url.searchParams.append(key, params[key].toString());
    }
  });
  return url.toString();
};

/**
 * Environment check
 */
export const isDevelopment = __DEV__;
export const isProduction = !__DEV__;

/**
 * Log API calls (only in development)
 */
export const logApiCall = (method: string, url: string, data?: any) => {
  if (isDevelopment) {
    console.log(`[API] ${method} ${url}`, data || '');
  }
};

// ====== EXPORT DEFAULT ======
export default API_CONFIG;
