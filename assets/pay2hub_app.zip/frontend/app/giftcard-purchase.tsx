import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TextInput,
  TouchableOpacity,
  Alert,
  ActivityIndicator,
  ScrollView,
  KeyboardAvoidingView,
  Platform,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { router, useLocalSearchParams } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';
import AsyncStorage from '@react-native-async-storage/async-storage';
import axios from 'axios';

const BACKEND_URL = process.env.EXPO_PUBLIC_BACKEND_URL || '';

export default function GiftCardPurchaseScreen() {
  const params = useLocalSearchParams();
  const brandId = params.brand_id as string;
  const brandName = params.brand_name as string;
  const minAmount = parseInt(params.min_amount as string) || 100;
  const maxAmount = parseInt(params.max_amount as string) || 10000;
  const denominationType = params.denomination_type as string;
  const rawDenominations = params.denominations as string;
  const commissionPercent = parseFloat(params.commission_percent as string) || 0;

  const [amount, setAmount] = useState('');
  const [loading, setLoading] = useState(false);
  const purchaseInProgress = React.useRef(false);

  // Parse denominations - handle string like "[500, 1000, 5000]"
  let parsedDenominations: number[] = [];
  if (rawDenominations && rawDenominations.length > 2) {
    try {
      parsedDenominations = JSON.parse(rawDenominations.replace(/'/g, '"'));
    } catch {
      // Try manual parsing
      const nums = rawDenominations.replace(/[\[\]]/g, '').split(',').map(s => parseInt(s.trim())).filter(n => !isNaN(n));
      if (nums.length > 0) parsedDenominations = nums;
    }
  }

  const isFixed = denominationType === 'FIXED' || denominationType === 'fixed';
  const quickAmounts = isFixed && parsedDenominations.length > 0
    ? parsedDenominations
    : [100, 250, 500, 1000, 2000, 5000];

  const getAuthHeader = async () => {
    const token = await AsyncStorage.getItem('auth_token');
    return { Authorization: `Bearer ${token}` };
  };

  const commission = amount ? (parseFloat(amount) * commissionPercent / 100).toFixed(2) : '0.00';

  const handlePurchase = async () => {
    // Prevent double tap
    if (purchaseInProgress.current) return;
    
    const amtNum = parseInt(amount);
    if (!amtNum || amtNum < minAmount) {
      Alert.alert('Error', `Minimum amount is ₹${minAmount}`);
      return;
    }
    if (amtNum > maxAmount) {
      Alert.alert('Error', `Maximum amount is ₹${maxAmount}`);
      return;
    }

    purchaseInProgress.current = true;
    setLoading(true);
    try {
      const headers = await getAuthHeader();
      const response = await axios.post(
        `${BACKEND_URL}/api/giftcards/purchase`,
        { brand_id: brandId, amount: amtNum },
        { headers, timeout: 120000 }
      );

      const data = response.data;
      
      // Check actual status from API response
      const actualStatus = data.status === 'success' ? 'success' 
        : (data.status === 'error' || data.status === 'failed') ? 'failed' 
        : 'pending';
      
      // Extract voucher details from vouchers array
      let vCode = data.voucher_code || '';
      let vPin = data.voucher_pin || '';
      let vExpiry = data.expiry_date || '';
      const vouchers = data.vouchers || [];
      if (vouchers.length > 0) {
        const v = vouchers[0];
        if (!vCode) vCode = v.code || '';
        if (!vPin) vPin = v.pin || '';
        if (!vExpiry) vExpiry = v.expiryDate || '';
      }
      
      router.replace({
        pathname: '/giftcard-status',
        params: {
          status: actualStatus,
          order_id: data.order_id || '',
          amount: amtNum.toString(),
          brand_name: brandName,
          commission: data.commission?.toString() || '0',
          message: data.message || '',
          voucher_code: vCode,
          voucher_pin: vPin,
          expiry_date: vExpiry,
        },
      });
    } catch (error: any) {
      const msg = error.response?.data?.detail || error.response?.data?.message || 'Purchase failed';
      router.replace({
        pathname: '/giftcard-status',
        params: {
          status: 'failed',
          order_id: '',
          amount: amtNum.toString(),
          brand_name: brandName,
          commission: '0',
          message: msg,
        },
      });
    } finally {
      setLoading(false);
      // Reset after navigation
      setTimeout(() => {
        purchaseInProgress.current = false;
      }, 3000);
    }
  };

  return (
    <SafeAreaView style={styles.container}>
      <KeyboardAvoidingView
        style={{ flex: 1 }}
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
      >
        <ScrollView contentContainerStyle={styles.scrollContent} showsVerticalScrollIndicator={false}>
          {/* Header */}
          <View style={styles.header}>
            <TouchableOpacity style={styles.backBtn} onPress={() => router.back()}>
              <Ionicons name="arrow-back" size={24} color="#1a1a2e" />
            </TouchableOpacity>
            <Text style={styles.headerTitle}>Buy Gift Card</Text>
            <View style={{ width: 40 }} />
          </View>

          {/* Brand Info Card */}
          <LinearGradient
            colors={['#6366f1', '#8b5cf6']}
            style={styles.brandCard}
          >
            <View style={styles.brandIconBg}>
              <Ionicons name="gift" size={28} color="#fff" />
            </View>
            <Text style={styles.brandNameText}>{brandName}</Text>
            <Text style={styles.brandRange}>₹{minAmount} - ₹{maxAmount}</Text>
            <View style={styles.commBadge}>
              <Text style={styles.commBadgeText}>{commissionPercent}% Commission</Text>
            </View>
          </LinearGradient>

          {/* Amount Input */}
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>
              {isFixed ? 'Select Amount' : 'Enter Amount'}
            </Text>
            {!isFixed && (
              <View style={styles.inputContainer}>
                <Text style={styles.rupeeSign}>₹</Text>
                <TextInput
                  style={styles.amountInput}
                  value={amount}
                  onChangeText={setAmount}
                  placeholder={`${minAmount} - ${maxAmount}`}
                  keyboardType="numeric"
                  placeholderTextColor="#bbb"
                />
              </View>
            )}
          </View>

          {/* Quick Amounts */}
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>Quick Select</Text>
            <View style={styles.quickGrid}>
              {quickAmounts.map((amt: number) => (
                <TouchableOpacity
                  key={amt}
                  style={[
                    styles.quickBtn,
                    amount === amt.toString() && styles.quickBtnActive,
                  ]}
                  onPress={() => setAmount(amt.toString())}
                >
                  <Text
                    style={[
                      styles.quickBtnText,
                      amount === amt.toString() && styles.quickBtnTextActive,
                    ]}
                  >
                    ₹{amt}
                  </Text>
                </TouchableOpacity>
              ))}
            </View>
          </View>

          {/* Commission Preview */}
          {amount ? (
            <View style={styles.previewCard}>
              <View style={styles.previewRow}>
                <Text style={styles.previewLabel}>Card Amount</Text>
                <Text style={styles.previewValue}>₹{amount}</Text>
              </View>
              <View style={styles.previewRow}>
                <Text style={styles.previewLabel}>Your Commission</Text>
                <Text style={[styles.previewValue, { color: '#22c55e' }]}>+₹{commission}</Text>
              </View>
              <View style={[styles.previewRow, styles.previewTotal]}>
                <Text style={styles.previewTotalLabel}>Debit from Wallet</Text>
                <Text style={styles.previewTotalValue}>₹{amount}</Text>
              </View>
            </View>
          ) : null}

          {/* Buy Button */}
          <TouchableOpacity
            style={[styles.buyButton, loading && styles.buyButtonDisabled]}
            onPress={handlePurchase}
            disabled={loading}
            activeOpacity={0.8}
          >
            <LinearGradient
              colors={loading ? ['#ccc', '#ccc'] : ['#f08a5d', '#e67e4a']}
              style={styles.buyGradient}
            >
              {loading ? (
                <ActivityIndicator color="#fff" />
              ) : (
                <>
                  <Ionicons name="gift" size={20} color="#fff" />
                  <Text style={styles.buyButtonText}>Purchase Gift Card</Text>
                </>
              )}
            </LinearGradient>
          </TouchableOpacity>
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f7fa',
  },
  scrollContent: {
    padding: 16,
    paddingBottom: 40,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 20,
  },
  backBtn: {
    width: 40,
    height: 40,
    borderRadius: 12,
    alignItems: 'center',
    justifyContent: 'center',
  },
  headerTitle: {
    flex: 1,
    fontSize: 20,
    fontWeight: '700',
    color: '#1a1a2e',
    textAlign: 'center',
  },
  brandCard: {
    borderRadius: 20,
    padding: 24,
    alignItems: 'center',
    marginBottom: 24,
  },
  brandIconBg: {
    width: 64,
    height: 64,
    borderRadius: 20,
    backgroundColor: 'rgba(255,255,255,0.2)',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 14,
  },
  brandNameText: {
    fontSize: 22,
    fontWeight: 'bold',
    color: '#fff',
  },
  brandRange: {
    fontSize: 14,
    color: 'rgba(255,255,255,0.8)',
    marginTop: 4,
  },
  commBadge: {
    marginTop: 12,
    backgroundColor: 'rgba(255,255,255,0.2)',
    borderRadius: 12,
    paddingHorizontal: 14,
    paddingVertical: 6,
  },
  commBadgeText: {
    fontSize: 12,
    fontWeight: '600',
    color: '#fff',
  },
  section: {
    marginBottom: 20,
  },
  sectionTitle: {
    fontSize: 15,
    fontWeight: '600',
    color: '#666',
    marginBottom: 10,
  },
  inputContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#fff',
    borderRadius: 16,
    paddingHorizontal: 16,
    borderWidth: 2,
    borderColor: '#f0f0f0',
  },
  rupeeSign: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#1a1a2e',
    marginRight: 8,
  },
  amountInput: {
    flex: 1,
    fontSize: 24,
    fontWeight: '700',
    color: '#1a1a2e',
    paddingVertical: 16,
  },
  quickGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 10,
  },
  quickBtn: {
    paddingHorizontal: 20,
    paddingVertical: 10,
    borderRadius: 12,
    backgroundColor: '#fff',
    borderWidth: 1,
    borderColor: '#e8e8e8',
  },
  quickBtnActive: {
    backgroundColor: '#f08a5d',
    borderColor: '#f08a5d',
  },
  quickBtnText: {
    fontSize: 14,
    fontWeight: '600',
    color: '#666',
  },
  quickBtnTextActive: {
    color: '#fff',
  },
  previewCard: {
    backgroundColor: '#fff',
    borderRadius: 16,
    padding: 16,
    marginBottom: 24,
  },
  previewRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingVertical: 10,
    borderBottomWidth: 1,
    borderBottomColor: '#f5f5f5',
  },
  previewLabel: {
    fontSize: 14,
    color: '#888',
  },
  previewValue: {
    fontSize: 14,
    fontWeight: '600',
    color: '#1a1a2e',
  },
  previewTotal: {
    borderBottomWidth: 0,
    paddingTop: 14,
  },
  previewTotalLabel: {
    fontSize: 15,
    fontWeight: '700',
    color: '#1a1a2e',
  },
  previewTotalValue: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#1a1a2e',
  },
  buyButton: {
    borderRadius: 16,
    overflow: 'hidden',
  },
  buyButtonDisabled: {
    opacity: 0.6,
  },
  buyGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 18,
    gap: 8,
  },
  buyButtonText: {
    fontSize: 16,
    fontWeight: '700',
    color: '#fff',
  },
});
