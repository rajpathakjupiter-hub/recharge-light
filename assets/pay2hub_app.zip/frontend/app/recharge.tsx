import React, { useState, useEffect, useRef } from 'react';
import {
  View, Text, StyleSheet, TextInput, TouchableOpacity, ScrollView,
  ActivityIndicator, Alert, FlatList, KeyboardAvoidingView, Platform,
  Animated, Modal,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { router, useLocalSearchParams } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';
import AsyncStorage from '@react-native-async-storage/async-storage';
import axios from 'axios';

const BACKEND_URL = process.env.EXPO_PUBLIC_BACKEND_URL || '';

interface Plan {
  rs: number;
  validity: string;
  desc: string;
  category: string;
}

interface PlanCategory {
  name: string;
  plans: Plan[];
}

interface Operator {
  code: string;
  name: string;
  commission: number;
}

interface Circle {
  code: string;
  name: string;
}

export default function RechargeScreen() {
  const { type } = useLocalSearchParams<{ type?: string }>();
  const [step, setStep] = useState<'operator' | 'number' | 'plan'>('operator');
  const [selectedOperator, setSelectedOperator] = useState('');
  const [selectedOperatorName, setSelectedOperatorName] = useState('');
  const [mobileNumber, setMobileNumber] = useState('');
  const [amount, setAmount] = useState('');
  const [operators, setOperators] = useState<{ prepaid: Operator[]; dth: Operator[] }>({ prepaid: [], dth: [] });
  const [categories, setCategories] = useState<PlanCategory[]>([]);
  const [allPlans, setAllPlans] = useState<Plan[]>([]);
  const [loading, setLoading] = useState(false);
  const [loadingPlans, setLoadingPlans] = useState(false);
  const [selectedPlan, setSelectedPlan] = useState<Plan | null>(null);
  const [activeCategory, setActiveCategory] = useState('popular plans');
  const [circles, setCircles] = useState<Circle[]>([]);
  const [selectedCircle, setSelectedCircle] = useState('del');
  const [showCircleModal, setShowCircleModal] = useState(false);

  const rechargeInProgress = useRef(false);
  const isDTH = (type || 'prepaid') === 'dth';

  useEffect(() => {
    fetchOperators();
    fetchCircles();
  }, []);

  useEffect(() => {
    if (selectedOperator && !isDTH) {
      fetchPlans(selectedOperator, selectedCircle);
    }
  }, [selectedOperator, selectedCircle]);

  const getAuthHeader = async () => {
    const token = await AsyncStorage.getItem('auth_token');
    return { Authorization: `Bearer ${token}` };
  };

  const fetchOperators = async () => {
    try {
      const headers = await getAuthHeader();
      const res = await axios.get(`${BACKEND_URL}/api/operators`, { headers });
      if (res.data) setOperators({ prepaid: res.data.prepaid || [], dth: res.data.dth || [] });
    } catch (e) { console.error(e); }
  };

  const fetchCircles = async () => {
    try {
      const res = await axios.get(`${BACKEND_URL}/api/circles`);
      if (res.data?.circles) setCircles(res.data.circles);
    } catch (e) { console.error(e); }
  };

  const fetchPlans = async (op: string, circle: string) => {
    setLoadingPlans(true);
    try {
      const headers = await getAuthHeader();
      const res = await axios.get(`${BACKEND_URL}/api/plans/${op}?circle=${circle}`, { headers });
      if (res.data?.categories) {
        setCategories(res.data.categories);
        setAllPlans(res.data.plans || []);
        if (res.data.categories.length > 0) {
          setActiveCategory(res.data.categories[0].name);
        }
      }
    } catch (e) { console.error(e); }
    finally { setLoadingPlans(false); }
  };

  const selectOperator = (op: Operator) => {
    setSelectedOperator(op.code);
    setSelectedOperatorName(op.name);
    setStep('number');
  };

  const goToPlans = () => {
    if (!mobileNumber || mobileNumber.length < 10) {
      Alert.alert('Error', isDTH ? 'Enter valid Subscriber ID' : 'Enter valid 10-digit mobile number');
      return;
    }
    setStep('plan');
  };

  const selectPlan = (plan: Plan) => {
    setSelectedPlan(plan);
    setAmount(plan.rs.toString());
  };

  const handleRecharge = async () => {
    if (rechargeInProgress.current) return;
    const amtNum = parseInt(amount);
    if (!amtNum || amtNum <= 0) { Alert.alert('Error', 'Enter valid amount'); return; }
    if (!mobileNumber || mobileNumber.length < 10) { Alert.alert('Error', 'Enter valid number'); return; }

    rechargeInProgress.current = true;
    setLoading(true);
    try {
      const headers = await getAuthHeader();
      const res = await axios.post(`${BACKEND_URL}/api/recharge`,
        { mobile_number: mobileNumber, operator_code: selectedOperator, amount: amtNum },
        { headers, timeout: 120000 }
      );
      router.push({
        pathname: '/status',
        params: {
          orderId: res.data.order_id || '', status: res.data.status || 'pending',
          amount, mobileNumber, operator: selectedOperatorName,
          transactionId: res.data.transaction_id || '',
          commission: res.data.commission?.toString() || '0',
          message: res.data.message || '',
        },
      });
    } catch (e: any) {
      router.push({
        pathname: '/status',
        params: { orderId: '', status: 'pending', amount, mobileNumber, operator: selectedOperatorName, transactionId: '', commission: '0', message: 'Processing...' },
      });
    } finally {
      setLoading(false);
      setTimeout(() => { rechargeInProgress.current = false; }, 3000);
    }
  };

  const getOpIcon = (c: string) => ({ jio: '📱', airtel: '📶', vi: '📞', bsnl: '🔵', tatasky: '📺', airteldth: '📡', dishtv: '🛰️', d2h: '📺', sundirect: '☀️' }[c] || '📱');
  const getOpColor = (c: string) => ({ jio: '#1a73e8', airtel: '#e40000', vi: '#6c2d91', bsnl: '#2196f3' }[c] || '#f08a5d');

  const currentPlans = categories.find(c => c.name === activeCategory)?.plans || [];

  const cleanDesc = (desc: string) => {
    // Remove "benefits:" prefix and clean up
    let clean = desc.replace(/^benefits:\s*/i, '').trim();
    // Remove numbered prefix like "1. "
    clean = clean.replace(/^\d+\.\s*/, '');
    return clean;
  };

  const formatValidity = (v: string) => {
    if (!v) return '';
    return v.replace('days', ' Days').replace('calendarmonth', 'Month').replace('day', ' Day');
  };

  const isSelected = (item: Plan) => selectedPlan?.rs === item.rs && selectedPlan?.desc === item.desc;

  const renderPlanItem = ({ item }: { item: Plan }) => {
    const selected = isSelected(item);
    const desc = cleanDesc(item.desc);
    const validity = formatValidity(item.validity);

    return (
      <TouchableOpacity
        style={[styles.planCard, selected && styles.planCardSelected]}
        onPress={() => selectPlan(item)}
        activeOpacity={0.7}
      >
        {/* Left: Amount */}
        <View style={[styles.planAmountBox, selected && styles.planAmountBoxSelected]}>
          <Text style={[styles.planRs, selected && styles.planRsSelected]}>₹{item.rs}</Text>
        </View>

        {/* Center: Details */}
        <View style={styles.planDetails}>
          <Text style={styles.planDesc} numberOfLines={2}>{desc}</Text>
          <View style={styles.planMeta}>
            <View style={styles.planMetaItem}>
              <Ionicons name="calendar-outline" size={11} color="#888" />
              <Text style={styles.planMetaText}>{validity}</Text>
            </View>
          </View>
        </View>

        {/* Right: Select */}
        <View style={[styles.planSelectCircle, selected && styles.planSelectCircleActive]}>
          {selected && <Ionicons name="checkmark" size={14} color="#fff" />}
        </View>
      </TouchableOpacity>
    );
  };

  return (
    <SafeAreaView style={styles.container}>
      <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === 'ios' ? 'padding' : 'height'}>
        {/* Header */}
        <View style={styles.header}>
          <TouchableOpacity style={styles.backBtn} onPress={() => {
            if (step === 'plan') setStep('number');
            else if (step === 'number') setStep('operator');
            else router.back();
          }}>
            <Ionicons name="arrow-back" size={24} color="#1a1a2e" />
          </TouchableOpacity>
          <Text style={styles.headerTitle}>{isDTH ? 'DTH Recharge' : 'Mobile Recharge'}</Text>
          <View style={{ width: 40 }} />
        </View>

        {/* Progress */}
        <View style={styles.progressRow}>
          {['Operator', 'Number', isDTH ? 'Amount' : 'Plan'].map((label, i) => {
            const steps = ['operator', 'number', 'plan'];
            const isActive = step === steps[i];
            const isDone = (step === 'number' && i === 0) || (step === 'plan' && i <= 1);
            return (
              <View key={label} style={styles.progressItem}>
                <View style={[styles.progressDot, isActive && styles.progressDotActive, isDone && styles.progressDotDone]}>
                  {isDone ? <Ionicons name="checkmark" size={12} color="#fff" /> :
                    <Text style={[styles.progressDotText, (isActive || isDone) && { color: '#fff' }]}>{i + 1}</Text>}
                </View>
                <Text style={[styles.progressLabel, isActive && styles.progressLabelActive]}>{label}</Text>
              </View>
            );
          })}
        </View>

        {/* Step 1: Operator */}
        {step === 'operator' && (
          <ScrollView contentContainerStyle={styles.stepContent}>
            <Text style={styles.stepTitle}>Select {isDTH ? 'DTH' : 'Mobile'} Operator</Text>
            <View style={styles.opGrid}>
              {(isDTH ? operators.dth : operators.prepaid).map(op => (
                <TouchableOpacity key={op.code} style={styles.opCard} onPress={() => selectOperator(op)} activeOpacity={0.7}>
                  <View style={[styles.opIcon, { backgroundColor: `${getOpColor(op.code)}12` }]}>
                    <Text style={{ fontSize: 28 }}>{getOpIcon(op.code)}</Text>
                  </View>
                  <Text style={styles.opName}>{op.name}</Text>
                </TouchableOpacity>
              ))}
            </View>
          </ScrollView>
        )}

        {/* Step 2: Number */}
        {step === 'number' && (
          <ScrollView contentContainerStyle={styles.stepContent} keyboardShouldPersistTaps="handled">
            <View style={styles.selectedBadge}>
              <Text style={{ fontSize: 22 }}>{getOpIcon(selectedOperator)}</Text>
              <View style={{ flex: 1 }}>
                <Text style={styles.selectedName}>{selectedOperatorName}</Text>
                <Text style={styles.selectedType}>{isDTH ? 'DTH' : 'Prepaid'}</Text>
              </View>
              <TouchableOpacity onPress={() => setStep('operator')}>
                <Text style={styles.changeText}>Change</Text>
              </TouchableOpacity>
            </View>
            <Text style={styles.inputLabel}>{isDTH ? 'Subscriber ID' : 'Mobile Number'}</Text>
            <View style={styles.numInputBox}>
              {!isDTH && <Text style={styles.prefix}>+91</Text>}
              <TextInput style={styles.numInput} value={mobileNumber} onChangeText={setMobileNumber}
                placeholder={isDTH ? 'Enter Subscriber ID' : 'Enter 10-digit number'}
                keyboardType="number-pad" maxLength={isDTH ? 12 : 10} placeholderTextColor="#bbb" />
            </View>
            <TouchableOpacity style={[styles.continueBtn, mobileNumber.length < 10 && { opacity: 0.4 }]}
              onPress={goToPlans} disabled={mobileNumber.length < 10}>
              <LinearGradient colors={['#f08a5d', '#e67e4a']} style={styles.continueBtnInner}>
                <Text style={styles.continueBtnText}>Continue</Text>
                <Ionicons name="arrow-forward" size={18} color="#fff" />
              </LinearGradient>
            </TouchableOpacity>
          </ScrollView>
        )}

        {/* Step 3: Plans */}
        {step === 'plan' && (
          <View style={{ flex: 1 }}>
            {/* Summary + Circle */}
            <View style={styles.planHeader}>
              <View style={styles.planSummary}>
                <Text style={styles.planSummaryNum}>{isDTH ? '' : '+91 '}{mobileNumber}</Text>
                <Text style={styles.planSummaryOp}>{selectedOperatorName}</Text>
              </View>
              {!isDTH && (
                <TouchableOpacity style={styles.circleBtn} onPress={() => setShowCircleModal(true)}>
                  <Ionicons name="location-outline" size={14} color="#f08a5d" />
                  <Text style={styles.circleBtnText}>{circles.find(c => c.code === selectedCircle)?.name || selectedCircle}</Text>
                  <Ionicons name="chevron-down" size={14} color="#f08a5d" />
                </TouchableOpacity>
              )}
            </View>

            {/* Amount + Recharge Button */}
            <View style={styles.amountRow}>
              <View style={styles.amountBox}>
                <Text style={styles.rupee}>₹</Text>
                <TextInput style={styles.amountInput} value={amount}
                  onChangeText={(t) => { setAmount(t); setSelectedPlan(null); }}
                  placeholder="Amount" keyboardType="numeric" placeholderTextColor="#bbb" />
              </View>
              <TouchableOpacity style={[styles.rechargeBtn, (!amount || loading) && { opacity: 0.4 }]}
                onPress={handleRecharge} disabled={!amount || loading}>
                <LinearGradient colors={['#f08a5d', '#e67e4a']} style={styles.rechargeBtnInner}>
                  {loading ? <ActivityIndicator color="#fff" size="small" /> : (
                    <><Ionicons name="flash" size={16} color="#fff" /><Text style={styles.rechargeBtnText}>Recharge</Text></>
                  )}
                </LinearGradient>
              </TouchableOpacity>
            </View>

            {/* Category Tabs */}
            {!isDTH && (
              <FlatList horizontal data={categories} keyExtractor={c => c.name}
                style={styles.catList} contentContainerStyle={styles.catListContent}
                showsHorizontalScrollIndicator={false}
                renderItem={({ item }) => (
                  <TouchableOpacity style={[styles.catTab, activeCategory === item.name && styles.catTabActive]}
                    onPress={() => setActiveCategory(item.name)}>
                    <Text style={[styles.catText, activeCategory === item.name && styles.catTextActive]}>
                      {item.name.charAt(0).toUpperCase() + item.name.slice(1)} ({item.plans.length})
                    </Text>
                  </TouchableOpacity>
                )}
              />
            )}

            {/* Plans List */}
            {loadingPlans ? (
              <View style={styles.loadingBox}><ActivityIndicator color="#f08a5d" size="large" /></View>
            ) : (
              <FlatList data={currentPlans} renderItem={renderPlanItem}
                keyExtractor={(item, i) => `${item.rs}-${i}`}
                contentContainerStyle={styles.plansList}
                showsVerticalScrollIndicator={false}
                ListEmptyComponent={<Text style={styles.emptyText}>No plans available</Text>}
              />
            )}

            {/* Circle Modal */}
            <Modal visible={showCircleModal} transparent animationType="slide">
              <TouchableOpacity style={styles.modalOverlay} onPress={() => setShowCircleModal(false)} activeOpacity={1}>
                <View style={styles.modalContent}>
                  <Text style={styles.modalTitle}>Select Circle</Text>
                  <FlatList data={circles} keyExtractor={c => c.code}
                    renderItem={({ item }) => (
                      <TouchableOpacity style={[styles.circleItem, selectedCircle === item.code && styles.circleItemActive]}
                        onPress={() => { setSelectedCircle(item.code); setShowCircleModal(false); }}>
                        <Text style={[styles.circleItemText, selectedCircle === item.code && { color: '#f08a5d', fontWeight: '700' }]}>
                          {item.name}
                        </Text>
                        {selectedCircle === item.code && <Ionicons name="checkmark" size={18} color="#f08a5d" />}
                      </TouchableOpacity>
                    )}
                  />
                </View>
              </TouchableOpacity>
            </Modal>
          </View>
        )}
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#f5f7fa' },
  header: { flexDirection: 'row', alignItems: 'center', paddingHorizontal: 16, paddingVertical: 10, backgroundColor: '#fff', borderBottomWidth: 1, borderBottomColor: '#f0f0f0' },
  backBtn: { width: 40, height: 40, borderRadius: 12, alignItems: 'center', justifyContent: 'center' },
  headerTitle: { flex: 1, fontSize: 18, fontWeight: '700', color: '#1a1a2e', textAlign: 'center' },
  progressRow: { flexDirection: 'row', justifyContent: 'center', gap: 32, paddingVertical: 14, backgroundColor: '#fff' },
  progressItem: { alignItems: 'center', gap: 4 },
  progressDot: { width: 26, height: 26, borderRadius: 13, backgroundColor: '#e8e8e8', alignItems: 'center', justifyContent: 'center' },
  progressDotActive: { backgroundColor: '#f08a5d' },
  progressDotDone: { backgroundColor: '#22c55e' },
  progressDotText: { fontSize: 12, fontWeight: '700', color: '#999' },
  progressLabel: { fontSize: 11, color: '#aaa', fontWeight: '500' },
  progressLabelActive: { color: '#f08a5d', fontWeight: '700' },
  stepContent: { padding: 16, paddingBottom: 40 },
  stepTitle: { fontSize: 18, fontWeight: '700', color: '#1a1a2e', marginBottom: 16 },
  opGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 12 },
  opCard: {
    width: '47%', backgroundColor: '#fff', borderRadius: 16, padding: 18, alignItems: 'center', gap: 10,
    ...Platform.select({ ios: { shadowColor: '#000', shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.06, shadowRadius: 12 }, android: { elevation: 3 } }),
  },
  opIcon: { width: 56, height: 56, borderRadius: 18, alignItems: 'center', justifyContent: 'center' },
  opName: { fontSize: 14, fontWeight: '700', color: '#1a1a2e' },
  selectedBadge: { flexDirection: 'row', alignItems: 'center', backgroundColor: '#fff', borderRadius: 14, padding: 14, gap: 12, marginBottom: 20 },
  selectedName: { fontSize: 15, fontWeight: '700', color: '#1a1a2e' },
  selectedType: { fontSize: 11, color: '#888' },
  changeText: { fontSize: 12, fontWeight: '600', color: '#f08a5d' },
  inputLabel: { fontSize: 14, fontWeight: '600', color: '#666', marginBottom: 8 },
  numInputBox: { flexDirection: 'row', alignItems: 'center', backgroundColor: '#fff', borderRadius: 14, paddingHorizontal: 16, borderWidth: 2, borderColor: '#f0f0f0', marginBottom: 20 },
  prefix: { fontSize: 16, fontWeight: '700', color: '#1a1a2e', marginRight: 8, paddingRight: 8, borderRightWidth: 1, borderRightColor: '#eee' },
  numInput: { flex: 1, fontSize: 18, fontWeight: '600', color: '#1a1a2e', paddingVertical: 16 },
  continueBtn: { borderRadius: 14, overflow: 'hidden' },
  continueBtnInner: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', paddingVertical: 16, gap: 8 },
  continueBtnText: { fontSize: 16, fontWeight: '700', color: '#fff' },
  planHeader: { flexDirection: 'row', alignItems: 'center', paddingHorizontal: 16, paddingVertical: 10, backgroundColor: '#fff', borderBottomWidth: 1, borderBottomColor: '#f0f0f0' },
  planSummary: { flex: 1 },
  planSummaryNum: { fontSize: 15, fontWeight: '700', color: '#1a1a2e' },
  planSummaryOp: { fontSize: 11, color: '#888' },
  circleBtn: { flexDirection: 'row', alignItems: 'center', gap: 4, paddingHorizontal: 10, paddingVertical: 6, backgroundColor: 'rgba(240,138,93,0.1)', borderRadius: 8 },
  circleBtnText: { fontSize: 12, fontWeight: '600', color: '#f08a5d' },
  amountRow: { flexDirection: 'row', gap: 10, paddingHorizontal: 16, paddingVertical: 10 },
  amountBox: { flex: 1, flexDirection: 'row', alignItems: 'center', backgroundColor: '#fff', borderRadius: 12, paddingHorizontal: 14, borderWidth: 2, borderColor: '#f0f0f0' },
  rupee: { fontSize: 20, fontWeight: 'bold', color: '#1a1a2e', marginRight: 6 },
  amountInput: { flex: 1, fontSize: 20, fontWeight: '700', color: '#1a1a2e', paddingVertical: 12 },
  rechargeBtn: { borderRadius: 12, overflow: 'hidden' },
  rechargeBtnInner: { flexDirection: 'row', alignItems: 'center', paddingHorizontal: 20, paddingVertical: 14, gap: 6 },
  rechargeBtnText: { fontSize: 14, fontWeight: '700', color: '#fff' },
  catList: { maxHeight: 44, backgroundColor: '#fff' },
  catListContent: { paddingHorizontal: 12, gap: 6, paddingVertical: 6 },
  catTab: { paddingHorizontal: 14, paddingVertical: 7, borderRadius: 20, backgroundColor: '#f0f0f0' },
  catTabActive: { backgroundColor: '#f08a5d' },
  catText: { fontSize: 12, fontWeight: '600', color: '#777' },
  catTextActive: { color: '#fff' },
  loadingBox: { flex: 1, alignItems: 'center', justifyContent: 'center', paddingTop: 40 },
  plansList: { padding: 12, gap: 10, paddingBottom: 30 },
  planCard: {
    flexDirection: 'row', alignItems: 'center', backgroundColor: '#fff', borderRadius: 16, padding: 14,
    borderWidth: 1.5, borderColor: '#f0f0f0',
    ...Platform.select({ ios: { shadowColor: '#000', shadowOffset: { width: 0, height: 1 }, shadowOpacity: 0.04, shadowRadius: 8 }, android: { elevation: 1 } }),
  },
  planCardSelected: { borderColor: '#f08a5d', backgroundColor: '#fff8f4' },
  planAmountBox: { width: 68, height: 56, borderRadius: 14, backgroundColor: '#f5f7fa', alignItems: 'center', justifyContent: 'center' },
  planAmountBoxSelected: { backgroundColor: 'rgba(240,138,93,0.12)' },
  planRs: { fontSize: 18, fontWeight: 'bold', color: '#1a1a2e' },
  planRsSelected: { color: '#f08a5d' },
  planDetails: { flex: 1, marginLeft: 14 },
  planDesc: { fontSize: 13, color: '#444', lineHeight: 18 },
  planMeta: { flexDirection: 'row', marginTop: 6, gap: 12 },
  planMetaItem: { flexDirection: 'row', alignItems: 'center', gap: 3, backgroundColor: '#f5f7fa', paddingHorizontal: 8, paddingVertical: 3, borderRadius: 8 },
  planMetaText: { fontSize: 11, color: '#888', fontWeight: '500' },
  planSelectCircle: { width: 24, height: 24, borderRadius: 12, borderWidth: 2, borderColor: '#ddd', alignItems: 'center', justifyContent: 'center', marginLeft: 10 },
  planSelectCircleActive: { backgroundColor: '#f08a5d', borderColor: '#f08a5d' },
  emptyText: { textAlign: 'center', color: '#999', paddingVertical: 40, fontSize: 14 },
  modalOverlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.5)', justifyContent: 'flex-end' },
  modalContent: { backgroundColor: '#fff', borderTopLeftRadius: 24, borderTopRightRadius: 24, maxHeight: '60%', padding: 20 },
  modalTitle: { fontSize: 18, fontWeight: '700', color: '#1a1a2e', marginBottom: 16 },
  circleItem: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingVertical: 14, borderBottomWidth: 1, borderBottomColor: '#f5f5f5' },
  circleItemActive: { backgroundColor: '#fff9f5' },
  circleItemText: { fontSize: 15, color: '#333' },
});
