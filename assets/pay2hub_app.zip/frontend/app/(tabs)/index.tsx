import React, { useEffect, useState, useCallback, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  RefreshControl,
  Animated,
  Dimensions,
  Image,
  Platform,
} from 'react-native';
import { router, useFocusEffect } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { SafeAreaView } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import AsyncStorage from '@react-native-async-storage/async-storage';
import axios from 'axios';

const BACKEND_URL = process.env.EXPO_PUBLIC_BACKEND_URL || '';
const { width: SCREEN_WIDTH } = Dimensions.get('window');

export default function HomeScreen() {
  const [balance, setBalance] = useState<number>(0);
  const [userName, setUserName] = useState<string>('');
  const [refreshing, setRefreshing] = useState(false);

  // Animation values
  const headerAnim = useRef(new Animated.Value(0)).current;
  const balanceAnim = useRef(new Animated.Value(0)).current;
  const cardScale = useRef(new Animated.Value(0.9)).current;
  const quickAction1 = useRef(new Animated.Value(0)).current;
  const quickAction2 = useRef(new Animated.Value(0)).current;
  const recentAnim = useRef(new Animated.Value(0)).current;
  const promoAnim = useRef(new Animated.Value(0)).current;
  const balanceCountAnim = useRef(new Animated.Value(0)).current;
  const pulseAnim = useRef(new Animated.Value(1)).current;

  const getAuthHeader = async () => {
    const token = await AsyncStorage.getItem('auth_token');
    return { Authorization: `Bearer ${token}` };
  };

  const fetchData = async () => {
    try {
      const headers = await getAuthHeader();

      const balanceRes = await axios.get(`${BACKEND_URL}/api/balance`, { headers });
      if (balanceRes.data.balance !== undefined) {
        setBalance(balanceRes.data.balance);
      }

      const userData = await AsyncStorage.getItem('user_data');
      if (userData) {
        const user = JSON.parse(userData);
        setUserName(user.name || 'User');
      }
    } catch (error: any) {
      console.error('Fetch error:', error);
      if (error.response?.status === 401) {
        await AsyncStorage.clear();
        router.replace('/login');
      }
    }
  };

  const startAnimations = () => {
    // Reset animations
    headerAnim.setValue(0);
    balanceAnim.setValue(0);
    cardScale.setValue(0.9);
    quickAction1.setValue(0);
    quickAction2.setValue(0);
    recentAnim.setValue(0);
    promoAnim.setValue(0);

    Animated.stagger(100, [
      // Header slide down
      Animated.spring(headerAnim, {
        toValue: 1,
        useNativeDriver: true,
        tension: 60,
        friction: 10,
      }),
      // Balance card scale + fade
      Animated.parallel([
        Animated.spring(balanceAnim, {
          toValue: 1,
          useNativeDriver: true,
          tension: 50,
          friction: 8,
        }),
        Animated.spring(cardScale, {
          toValue: 1,
          useNativeDriver: true,
          tension: 50,
          friction: 8,
        }),
      ]),
      // Quick actions slide in
      Animated.spring(quickAction1, {
        toValue: 1,
        useNativeDriver: true,
        tension: 60,
        friction: 9,
      }),
      Animated.spring(quickAction2, {
        toValue: 1,
        useNativeDriver: true,
        tension: 60,
        friction: 9,
      }),
      // Promo banner
      Animated.spring(promoAnim, {
        toValue: 1,
        useNativeDriver: true,
        tension: 50,
        friction: 10,
      }),
      // Recent activity
      Animated.spring(recentAnim, {
        toValue: 1,
        useNativeDriver: true,
        tension: 50,
        friction: 10,
      }),
    ]).start();

    // Pulse animation for add money button
    Animated.loop(
      Animated.sequence([
        Animated.timing(pulseAnim, {
          toValue: 1.05,
          duration: 1500,
          useNativeDriver: true,
        }),
        Animated.timing(pulseAnim, {
          toValue: 1,
          duration: 1500,
          useNativeDriver: true,
        }),
      ])
    ).start();
  };

  useFocusEffect(
    useCallback(() => {
      fetchData();
      startAnimations();
    }, [])
  );

  const onRefresh = async () => {
    setRefreshing(true);
    await fetchData();
    setRefreshing(false);
    startAnimations();
  };

  const handleRecharge = (type: 'prepaid' | 'dth') => {
    router.push({
      pathname: '/recharge',
      params: { type },
    });
  };

  const getGreeting = () => {
    const hour = new Date().getHours();
    if (hour < 12) return 'Good Morning';
    if (hour < 17) return 'Good Afternoon';
    return 'Good Evening';
  };

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView
        contentContainerStyle={styles.scrollContent}
        showsVerticalScrollIndicator={false}
        refreshControl={
          <RefreshControl
            refreshing={refreshing}
            onRefresh={onRefresh}
            tintColor="#f08a5d"
          />
        }
      >
        {/* Header with Logo */}
        <Animated.View
          style={[
            styles.header,
            {
              opacity: headerAnim,
              transform: [
                {
                  translateY: headerAnim.interpolate({
                    inputRange: [0, 1],
                    outputRange: [-30, 0],
                  }),
                },
              ],
            },
          ]}
        >
          <View style={styles.headerLeft}>
            <Text style={styles.greeting}>{getGreeting()} 👋</Text>
            <Text style={styles.userName}>{userName}</Text>
          </View>
          <View style={styles.headerRight}>
            <TouchableOpacity style={styles.notifButton}>
              <Ionicons name="notifications-outline" size={22} color="#1a1a2e" />
              <View style={styles.notifDot} />
            </TouchableOpacity>
            <View style={styles.logoContainer}>
              <Image
                source={require('../../assets/images/pay2hub-logo.png')}
                style={styles.logoImage}
                resizeMode="contain"
              />
            </View>
          </View>
        </Animated.View>

        {/* Balance Card with Gradient */}
        <Animated.View
          style={[
            {
              opacity: balanceAnim,
              transform: [{ scale: cardScale }],
            },
          ]}
        >
          <LinearGradient
            colors={['#f08a5d', '#e67e4a', '#d4723e']}
            start={{ x: 0, y: 0 }}
            end={{ x: 1, y: 1 }}
            style={styles.balanceCard}
          >
            {/* Decorative circles */}
            <View style={styles.decorCircle1} />
            <View style={styles.decorCircle2} />

            <View style={styles.balanceTop}>
              <View style={styles.balanceIconContainer}>
                <Ionicons name="wallet" size={20} color="#fff" />
              </View>
              <Text style={styles.balanceLabel}>Wallet Balance</Text>
            </View>

            <Text style={styles.balanceAmount}>
              ₹{balance.toFixed(2)}
            </Text>

            <View style={styles.balanceActions}>
              <Animated.View style={{ transform: [{ scale: pulseAnim }] }}>
                <TouchableOpacity
                  style={styles.addMoneyButton}
                  onPress={() => router.push('/add-money')}
                  activeOpacity={0.8}
                >
                  <Ionicons name="add-circle" size={18} color="#f08a5d" />
                  <Text style={styles.addMoneyText}>Add Money</Text>
                </TouchableOpacity>
              </Animated.View>

              <TouchableOpacity
                style={styles.historyButton}
                onPress={() => router.push('/(tabs)/history')}
                activeOpacity={0.8}
              >
                <Ionicons name="time-outline" size={18} color="#fff" />
                <Text style={styles.historyButtonText}>History</Text>
              </TouchableOpacity>
            </View>
          </LinearGradient>
        </Animated.View>

        {/* Quick Recharge Section */}
        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <Text style={styles.sectionTitle}>Quick Recharge</Text>
            <Ionicons name="flash" size={18} color="#f08a5d" />
          </View>

          <View style={styles.quickActions}>
            {/* Mobile Recharge */}
            <Animated.View
              style={[
                styles.actionCardWrapper,
                {
                  opacity: quickAction1,
                  transform: [
                    {
                      translateX: quickAction1.interpolate({
                        inputRange: [0, 1],
                        outputRange: [-50, 0],
                      }),
                    },
                  ],
                },
              ]}
            >
              <TouchableOpacity
                style={styles.actionCard}
                onPress={() => handleRecharge('prepaid')}
                activeOpacity={0.7}
              >
                <LinearGradient
                  colors={['rgba(240,138,93,0.15)', 'rgba(240,138,93,0.05)']}
                  style={styles.actionIconGradient}
                >
                  <View style={styles.actionIconInner}>
                    <Ionicons name="phone-portrait" size={28} color="#f08a5d" />
                  </View>
                </LinearGradient>
                <Text style={styles.actionText}>Mobile</Text>
                <Text style={styles.actionSubtext}>Prepaid</Text>
                <View style={styles.actionArrow}>
                  <Ionicons name="arrow-forward-circle" size={22} color="#f08a5d" />
                </View>
              </TouchableOpacity>
            </Animated.View>

            {/* DTH Recharge */}
            <Animated.View
              style={[
                styles.actionCardWrapper,
                {
                  opacity: quickAction2,
                  transform: [
                    {
                      translateX: quickAction2.interpolate({
                        inputRange: [0, 1],
                        outputRange: [50, 0],
                      }),
                    },
                  ],
                },
              ]}
            >
              <TouchableOpacity
                style={styles.actionCard}
                onPress={() => handleRecharge('dth')}
                activeOpacity={0.7}
              >
                <LinearGradient
                  colors={['rgba(99,102,241,0.15)', 'rgba(99,102,241,0.05)']}
                  style={styles.actionIconGradient}
                >
                  <View style={[styles.actionIconInner, { backgroundColor: 'rgba(99,102,241,0.12)' }]}>
                    <Ionicons name="tv" size={28} color="#6366f1" />
                  </View>
                </LinearGradient>
                <Text style={styles.actionText}>DTH</Text>
                <Text style={styles.actionSubtext}>Recharge</Text>
                <View style={styles.actionArrow}>
                  <Ionicons name="arrow-forward-circle" size={22} color="#6366f1" />
                </View>
              </TouchableOpacity>
            </Animated.View>
          </View>
        </View>

        {/* Promo Banner */}
        <Animated.View
          style={[
            {
              opacity: promoAnim,
              transform: [
                {
                  translateY: promoAnim.interpolate({
                    inputRange: [0, 1],
                    outputRange: [30, 0],
                  }),
                },
              ],
            },
          ]}
        >
          <TouchableOpacity
            activeOpacity={0.8}
            onPress={() => router.push('/giftcards')}
          >
            <LinearGradient
              colors={['#6366f1', '#8b5cf6']}
              start={{ x: 0, y: 0 }}
              end={{ x: 1, y: 0 }}
              style={styles.promoBanner}
            >
              <View style={styles.promoContent}>
                <View style={styles.promoIconBg}>
                  <Ionicons name="gift" size={24} color="#fff" />
                </View>
                <View style={styles.promoText}>
                  <Text style={styles.promoTitle}>Gift Cards</Text>
                  <Text style={styles.promoSubtitle}>
                    Buy gift cards & earn commission!
                  </Text>
                </View>
              </View>
              <View style={styles.promoButton}>
                <Text style={styles.promoButtonText}>Shop</Text>
                <Ionicons name="chevron-forward" size={14} color="#6366f1" />
              </View>
            </LinearGradient>
          </TouchableOpacity>
        </Animated.View>

        {/* Services Grid */}
        <Animated.View
          style={[
            styles.section,
            {
              opacity: recentAnim,
              transform: [
                {
                  translateY: recentAnim.interpolate({
                    inputRange: [0, 1],
                    outputRange: [30, 0],
                  }),
                },
              ],
            },
          ]}
        >
          <View style={styles.sectionHeader}>
            <Text style={styles.sectionTitle}>Quick Actions</Text>
          </View>

          <View style={styles.servicesGrid}>
            <TouchableOpacity
              style={styles.serviceItem}
              onPress={() => router.push('/(tabs)/wallet')}
            >
              <View style={[styles.serviceIcon, { backgroundColor: 'rgba(34,197,94,0.12)' }]}>
                <Ionicons name="wallet-outline" size={24} color="#22c55e" />
              </View>
              <Text style={styles.serviceText}>Wallet</Text>
            </TouchableOpacity>

            <TouchableOpacity
              style={styles.serviceItem}
              onPress={() => router.push('/giftcards')}
            >
              <View style={[styles.serviceIcon, { backgroundColor: 'rgba(99,102,241,0.12)' }]}>
                <Ionicons name="gift-outline" size={24} color="#6366f1" />
              </View>
              <Text style={styles.serviceText}>Gift Cards</Text>
            </TouchableOpacity>

            <TouchableOpacity
              style={styles.serviceItem}
              onPress={() => router.push('/(tabs)/margin')}
            >
              <View style={[styles.serviceIcon, { backgroundColor: 'rgba(168,85,247,0.12)' }]}>
                <Ionicons name="cash-outline" size={24} color="#a855f7" />
              </View>
              <Text style={styles.serviceText}>Margin</Text>
            </TouchableOpacity>

            <TouchableOpacity
              style={styles.serviceItem}
              onPress={() => router.push('/(tabs)/history')}
            >
              <View style={[styles.serviceIcon, { backgroundColor: 'rgba(59,130,246,0.12)' }]}>
                <Ionicons name="receipt-outline" size={24} color="#3b82f6" />
              </View>
              <Text style={styles.serviceText}>History</Text>
            </TouchableOpacity>
          </View>
        </Animated.View>

        {/* Bottom Spacer */}
        <View style={{ height: Platform.OS === 'ios' ? 20 : 10 }} />
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f7fa',
  },
  scrollContent: {
    padding: 16,
    paddingBottom: Platform.OS === 'ios' ? 110 : 100,
  },
  // Header
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 20,
  },
  headerLeft: {
    flex: 1,
  },
  greeting: {
    fontSize: 14,
    color: '#888',
    marginBottom: 2,
  },
  userName: {
    fontSize: 22,
    fontWeight: 'bold',
    color: '#1a1a2e',
  },
  headerRight: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  notifButton: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: '#fff',
    alignItems: 'center',
    justifyContent: 'center',
    ...Platform.select({
      ios: {
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 2 },
        shadowOpacity: 0.08,
        shadowRadius: 8,
      },
      android: {
        elevation: 3,
      },
    }),
  },
  notifDot: {
    position: 'absolute',
    top: 10,
    right: 11,
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: '#ef4444',
    borderWidth: 2,
    borderColor: '#fff',
  },
  logoContainer: {
    width: 44,
    height: 44,
    borderRadius: 14,
    overflow: 'hidden',
    ...Platform.select({
      ios: {
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 2 },
        shadowOpacity: 0.1,
        shadowRadius: 8,
      },
      android: {
        elevation: 4,
      },
    }),
  },
  logoImage: {
    width: 44,
    height: 44,
    borderRadius: 14,
  },
  // Balance Card
  balanceCard: {
    borderRadius: 24,
    padding: 24,
    marginBottom: 24,
    overflow: 'hidden',
  },
  decorCircle1: {
    position: 'absolute',
    top: -40,
    right: -40,
    width: 120,
    height: 120,
    borderRadius: 60,
    backgroundColor: 'rgba(255,255,255,0.1)',
  },
  decorCircle2: {
    position: 'absolute',
    bottom: -30,
    left: -20,
    width: 80,
    height: 80,
    borderRadius: 40,
    backgroundColor: 'rgba(255,255,255,0.08)',
  },
  balanceTop: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginBottom: 8,
  },
  balanceIconContainer: {
    width: 32,
    height: 32,
    borderRadius: 10,
    backgroundColor: 'rgba(255,255,255,0.2)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  balanceLabel: {
    fontSize: 14,
    color: 'rgba(255,255,255,0.85)',
    fontWeight: '500',
  },
  balanceAmount: {
    fontSize: 38,
    fontWeight: 'bold',
    color: '#fff',
    marginBottom: 20,
    letterSpacing: 0.5,
  },
  balanceActions: {
    flexDirection: 'row',
    gap: 12,
  },
  addMoneyButton: {
    backgroundColor: '#fff',
    borderRadius: 14,
    paddingVertical: 12,
    paddingHorizontal: 20,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  addMoneyText: {
    fontSize: 14,
    fontWeight: '700',
    color: '#f08a5d',
  },
  historyButton: {
    backgroundColor: 'rgba(255,255,255,0.2)',
    borderRadius: 14,
    paddingVertical: 12,
    paddingHorizontal: 20,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.3)',
  },
  historyButtonText: {
    fontSize: 14,
    fontWeight: '600',
    color: '#fff',
  },
  // Section
  section: {
    marginBottom: 20,
  },
  sectionHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 14,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: '700',
    color: '#1a1a2e',
  },
  // Quick Actions
  quickActions: {
    flexDirection: 'row',
    gap: 14,
  },
  actionCardWrapper: {
    flex: 1,
  },
  actionCard: {
    backgroundColor: '#fff',
    borderRadius: 16,
    padding: 14,
    alignItems: 'center',
    ...Platform.select({
      ios: {
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 4 },
        shadowOpacity: 0.08,
        shadowRadius: 16,
      },
      android: {
        elevation: 4,
      },
    }),
  },
  actionIconGradient: {
    width: 52,
    height: 52,
    borderRadius: 16,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 10,
  },
  actionIconInner: {
    width: 40,
    height: 40,
    borderRadius: 12,
    backgroundColor: 'rgba(240,138,93,0.12)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  actionText: {
    fontSize: 14,
    fontWeight: '700',
    color: '#1a1a2e',
    marginBottom: 1,
  },
  actionSubtext: {
    fontSize: 11,
    color: '#888',
    marginBottom: 6,
  },
  actionArrow: {
    opacity: 0.6,
  },
  // Promo Banner
  promoBanner: {
    borderRadius: 18,
    padding: 18,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 20,
    overflow: 'hidden',
  },
  promoContent: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
    gap: 14,
  },
  promoIconBg: {
    width: 44,
    height: 44,
    borderRadius: 14,
    backgroundColor: 'rgba(255,255,255,0.2)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  promoText: {
    flex: 1,
  },
  promoTitle: {
    fontSize: 15,
    fontWeight: '700',
    color: '#fff',
  },
  promoSubtitle: {
    fontSize: 12,
    color: 'rgba(255,255,255,0.8)',
    marginTop: 2,
  },
  promoButton: {
    backgroundColor: '#fff',
    borderRadius: 10,
    paddingVertical: 8,
    paddingHorizontal: 14,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  promoButtonText: {
    fontSize: 12,
    fontWeight: '700',
    color: '#6366f1',
  },
  // Services Grid
  servicesGrid: {
    flexDirection: 'row',
    backgroundColor: '#fff',
    borderRadius: 20,
    padding: 16,
    ...Platform.select({
      ios: {
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 4 },
        shadowOpacity: 0.06,
        shadowRadius: 16,
      },
      android: {
        elevation: 3,
      },
    }),
  },
  serviceItem: {
    flex: 1,
    alignItems: 'center',
    gap: 8,
  },
  serviceIcon: {
    width: 52,
    height: 52,
    borderRadius: 16,
    alignItems: 'center',
    justifyContent: 'center',
  },
  serviceText: {
    fontSize: 11,
    fontWeight: '600',
    color: '#666',
    textAlign: 'center',
  },
});
