import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  FlatList,
  TouchableOpacity,
  ActivityIndicator,
  Platform,
  RefreshControl,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { router } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import AsyncStorage from '@react-native-async-storage/async-storage';
import axios from 'axios';

const BACKEND_URL = process.env.EXPO_PUBLIC_BACKEND_URL || '';

interface GiftCardOrder {
  id: string;
  brand_name: string;
  amount: number;
  commission: number;
  status: string;
  voucher_code?: string;
  voucher_pin?: string;
  created_at: string;
}

export default function GiftCardHistoryScreen() {
  const [orders, setOrders] = useState<GiftCardOrder[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  const getAuthHeader = async () => {
    const token = await AsyncStorage.getItem('auth_token');
    return { Authorization: `Bearer ${token}` };
  };

  const fetchHistory = async () => {
    try {
      const headers = await getAuthHeader();
      const response = await axios.get(`${BACKEND_URL}/api/giftcards/history`, { headers });
      if (response.data?.orders) {
        setOrders(response.data.orders);
      }
    } catch (error) {
      console.error('Fetch giftcard history error:', error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchHistory();
  }, []);

  const onRefresh = async () => {
    setRefreshing(true);
    await fetchHistory();
    setRefreshing(false);
  };

  const getStatusColor = (s: string) => {
    switch (s) {
      case 'success': return '#22c55e';
      case 'failed': return '#ef4444';
      default: return '#f08a5d';
    }
  };

  const renderOrder = ({ item }: { item: GiftCardOrder }) => (
    <View style={styles.orderCard}>
      <View style={styles.orderHeader}>
        <View style={[styles.statusDot, { backgroundColor: getStatusColor(item.status) }]} />
        <Text style={styles.orderBrand}>{item.brand_name}</Text>
        <Text style={[styles.orderStatus, { color: getStatusColor(item.status) }]}>
          {item.status.toUpperCase()}
        </Text>
      </View>
      <View style={styles.orderBody}>
        <View style={styles.orderDetail}>
          <Text style={styles.detailLabel}>Amount</Text>
          <Text style={styles.detailValue}>₹{item.amount}</Text>
        </View>
        {item.commission > 0 && (
          <View style={styles.orderDetail}>
            <Text style={styles.detailLabel}>Commission</Text>
            <Text style={[styles.detailValue, { color: '#22c55e' }]}>+₹{item.commission}</Text>
          </View>
        )}
        {(item.voucher_code || item.voucher_pin) && (
          <View style={styles.voucherRow}>
            <Ionicons name="gift" size={16} color="#6366f1" />
            <Text style={styles.voucherText}>
              {item.voucher_code || item.voucher_pin}
            </Text>
            {item.voucher_code && item.voucher_pin && (
              <Text style={styles.voucherPinText}>PIN: {item.voucher_pin}</Text>
            )}
          </View>
        )}
        <Text style={styles.orderDate}>{item.created_at}</Text>
      </View>
    </View>
  );

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity style={styles.backBtn} onPress={() => router.back()}>
          <Ionicons name="arrow-back" size={24} color="#1a1a2e" />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Gift Card History</Text>
        <View style={{ width: 40 }} />
      </View>

      {loading ? (
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color="#f08a5d" />
        </View>
      ) : (
        <FlatList
          data={orders}
          renderItem={renderOrder}
          keyExtractor={(item) => item.id}
          contentContainerStyle={styles.listContent}
          refreshControl={
            <RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor="#f08a5d" />
          }
          ListEmptyComponent={
            <View style={styles.emptyContainer}>
              <Ionicons name="gift-outline" size={56} color="#ccc" />
              <Text style={styles.emptyText}>No gift card purchases yet</Text>
            </View>
          }
        />
      )}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f7fa',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingVertical: 12,
    backgroundColor: '#fff',
    borderBottomWidth: 1,
    borderBottomColor: '#f0f0f0',
  },
  backBtn: {
    width: 40,
    height: 40,
    borderRadius: 12,
    alignItems: 'center',
    justifyContent: 'center',
  },
  headerTitle: {
    flex: 1,
    fontSize: 18,
    fontWeight: '700',
    color: '#1a1a2e',
    textAlign: 'center',
  },
  loadingContainer: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  listContent: {
    padding: 16,
    gap: 12,
  },
  orderCard: {
    backgroundColor: '#fff',
    borderRadius: 16,
    padding: 16,
    ...Platform.select({
      ios: {
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 2 },
        shadowOpacity: 0.06,
        shadowRadius: 12,
      },
      android: { elevation: 3 },
    }),
  },
  orderHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 12,
    gap: 8,
  },
  statusDot: {
    width: 10,
    height: 10,
    borderRadius: 5,
  },
  orderBrand: {
    flex: 1,
    fontSize: 16,
    fontWeight: '700',
    color: '#1a1a2e',
  },
  orderStatus: {
    fontSize: 12,
    fontWeight: '700',
  },
  orderBody: {
    gap: 8,
  },
  orderDetail: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  detailLabel: {
    fontSize: 13,
    color: '#888',
  },
  detailValue: {
    fontSize: 14,
    fontWeight: '600',
    color: '#1a1a2e',
  },
  voucherRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    backgroundColor: '#f5f0ff',
    borderRadius: 8,
    padding: 10,
    marginTop: 4,
  },
  voucherText: {
    fontSize: 14,
    fontWeight: '700',
    color: '#6366f1',
    letterSpacing: 1,
    flex: 1,
  },
  voucherPinText: {
    fontSize: 12,
    fontWeight: '600',
    color: '#888',
  },
  orderDate: {
    fontSize: 11,
    color: '#bbb',
    marginTop: 4,
  },
  emptyContainer: {
    alignItems: 'center',
    paddingVertical: 60,
    gap: 12,
  },
  emptyText: {
    fontSize: 14,
    color: '#999',
  },
});
