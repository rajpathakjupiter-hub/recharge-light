import React, { useState, useRef, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TextInput,
  TouchableOpacity,
  KeyboardAvoidingView,
  Platform,
  ScrollView,
  ActivityIndicator,
  Alert,
  Image,
  Animated,
  Dimensions,
} from 'react-native';
import { router } from 'expo-router';
import { Ionicons, MaterialCommunityIcons } from '@expo/vector-icons';
import AsyncStorage from '@react-native-async-storage/async-storage';
import axios from 'axios';
import { LinearGradient } from 'expo-linear-gradient';

const BACKEND_URL = process.env.EXPO_PUBLIC_BACKEND_URL || '';
const { width: SCREEN_WIDTH, height: SCREEN_HEIGHT } = Dimensions.get('window');

export default function UltraLoginScreen() {
  const [mobile, setMobile] = useState('');
  const [otp, setOtp] = useState('');
  const [step, setStep] = useState<'mobile' | 'otp'>('mobile');
  const [loading, setLoading] = useState(false);
  const [isNewUser, setIsNewUser] = useState(false);

  // Animations
  const logoScale = useRef(new Animated.Value(0.3)).current;
  const logoOpacity = useRef(new Animated.Value(0)).current;
  const formSlide = useRef(new Animated.Value(50)).current;
  const formOpacity = useRef(new Animated.Value(0)).current;
  const badgeFloat = useRef(new Animated.Value(0)).current;
  const pulseAnim = useRef(new Animated.Value(1)).current;

  useEffect(() => {
    // Entry Animations
    Animated.parallel([
      Animated.spring(logoScale, {
        toValue: 1,
        tension: 40,
        friction: 7,
        useNativeDriver: true,
      }),
      Animated.timing(logoOpacity, {
        toValue: 1,
        duration: 800,
        useNativeDriver: true,
      }),
      Animated.timing(formSlide, {
        toValue: 0,
        duration: 600,
        delay: 200,
        useNativeDriver: true,
      }),
      Animated.timing(formOpacity, {
        toValue: 1,
        duration: 600,
        delay: 200,
        useNativeDriver: true,
      }),
    ]).start();

    // Floating badge animation
    Animated.loop(
      Animated.sequence([
        Animated.timing(badgeFloat, {
          toValue: -8,
          duration: 2000,
          useNativeDriver: true,
        }),
        Animated.timing(badgeFloat, {
          toValue: 0,
          duration: 2000,
          useNativeDriver: true,
        }),
      ])
    ).start();

    // Button pulse
    Animated.loop(
      Animated.sequence([
        Animated.timing(pulseAnim, {
          toValue: 1.02,
          duration: 1000,
          useNativeDriver: true,
        }),
        Animated.timing(pulseAnim, {
          toValue: 1,
          duration: 1000,
          useNativeDriver: true,
        }),
      ])
    ).start();
  }, []);

  const sendOTP = async () => {
    if (mobile.length !== 10) {
      Alert.alert('Error', 'Please enter a valid 10-digit mobile number');
      return;
    }

    setLoading(true);
    try {
      const response = await axios.post(`${BACKEND_URL}/api/auth/send-otp`, {
        mobile: mobile,
      });
      
      if (response.data.message) {
        setIsNewUser(response.data.is_new_user || false);
        setStep('otp');
        Alert.alert('Success', 'OTP sent successfully!');
      } else {
        Alert.alert('Error', response.data.error || 'Failed to send OTP');
      }
    } catch (error: any) {
      Alert.alert('Error', error.response?.data?.detail || 'Failed to send OTP');
    } finally {
      setLoading(false);
    }
  };

  const verifyOTP = async () => {
    if (otp.length !== 6) {
      Alert.alert('Error', 'Please enter a valid 6-digit OTP');
      return;
    }

    setLoading(true);
    try {
      const response = await axios.post(`${BACKEND_URL}/api/auth/verify-otp`, {
        mobile: mobile,
        otp: otp,
      });
      
      if (response.data.token) {
        await AsyncStorage.setItem('auth_token', response.data.token);
        await AsyncStorage.setItem('user_data', JSON.stringify(response.data.user));
        router.replace('/(tabs)');
      } else if (isNewUser) {
        router.push({
          pathname: '/register',
          params: { mobile, otp },
        });
      } else {
        Alert.alert('Error', response.data.message || 'Invalid OTP');
      }
    } catch (error: any) {
      Alert.alert('Error', error.response?.data?.detail || 'Verification failed');
    } finally {
      setLoading(false);
    }
  };

  return (
    <View style={styles.container}>
      {/* Animated Background */}
      <LinearGradient
        colors={['#f0f9ff', '#e0f2fe', '#fff']}
        style={StyleSheet.absoluteFillObject}
      >
        {/* Decorative Circles */}
        <View style={[styles.decorCircle, styles.decorCircle1]} />
        <View style={[styles.decorCircle, styles.decorCircle2]} />
        <View style={[styles.decorCircle, styles.decorCircle3]} />
      </LinearGradient>

      <KeyboardAvoidingView
        style={{ flex: 1 }}
        behavior={Platform.OS === 'ios' ? 'padding' : undefined}
      >
        <ScrollView
          contentContainerStyle={styles.scrollContent}
          showsVerticalScrollIndicator={false}
          keyboardShouldPersistTaps="handled"
        >
          {/* Logo Section with Glow */}
          <Animated.View
            style={[
              styles.logoSection,
              {
                opacity: logoOpacity,
                transform: [{ scale: logoScale }],
              },
            ]}
          >
            <View style={styles.logoGlowContainer}>
              <View style={styles.logoGlow} />
              <LinearGradient
                colors={['#ff9a56', '#ff6b35', '#ff4517']}
                start={{ x: 0, y: 0 }}
                end={{ x: 1, y: 1 }}
                style={styles.logoGradientBg}
              >
                <Image
                  source={require('../assets/images/pay2hub-logo.png')}
                  style={styles.logoImage}
                  resizeMode="contain"
                />
              </LinearGradient>
            </View>
            
            <Text style={styles.appTitle}>Pay2Hub</Text>
            <Text style={styles.appTagline}>Fast & Secure Recharges</Text>

            {/* Trust Badges */}
            <Animated.View
              style={[
                styles.trustBadges,
                { transform: [{ translateY: badgeFloat }] },
              ]}
            >
              <View style={styles.badge}>
                <Ionicons name="shield-checkmark" size={14} color="#10b981" />
                <Text style={styles.badgeText}>256-bit SSL</Text>
              </View>
              <View style={styles.badge}>
                <Ionicons name="lock-closed" size={14} color="#6366f1" />
                <Text style={styles.badgeText}>End-to-End Encrypted</Text>
              </View>
            </Animated.View>
          </Animated.View>

          {/* Form Card with Glass Effect */}
          <Animated.View
            style={[
              styles.formCard,
              {
                opacity: formOpacity,
                transform: [{ translateY: formSlide }],
              },
            ]}
          >
            <LinearGradient
              colors={['rgba(255,255,255,0.95)', 'rgba(255,255,255,0.85)']}
              style={styles.formGradient}
            >
              <View style={styles.formHeader}>
                <Text style={styles.formTitle}>
                  {step === 'mobile' ? 'Login / Register' : 'Verify OTP'}
                </Text>
                <Text style={styles.formSubtitle}>
                  {step === 'mobile'
                    ? 'Enter your mobile number to continue'
                    : `Enter the 6-digit OTP sent to +91 ${mobile}`}
                </Text>
              </View>

              {step === 'mobile' ? (
                <>
                  {/* Mobile Input with Modern Design */}
                  <View style={styles.inputGroup}>
                    <Text style={styles.inputLabel}>Mobile Number</Text>
                    <View style={styles.modernInputContainer}>
                      <View style={styles.countryCodeBox}>
                        <Image
                          source={{ uri: 'https://flagcdn.com/w40/in.png' }}
                          style={styles.flagIcon}
                        />
                        <Text style={styles.countryCodeText}>+91</Text>
                      </View>
                      <View style={styles.inputDivider} />
                      <TextInput
                        style={styles.modernInput}
                        placeholder="Enter 10-digit mobile"
                        placeholderTextColor="#94a3b8"
                        keyboardType="phone-pad"
                        maxLength={10}
                        value={mobile}
                        onChangeText={setMobile}
                      />
                    </View>
                  </View>

                  {/* Modern Button with Gradient */}
                  <Animated.View style={{ transform: [{ scale: pulseAnim }] }}>
                    <TouchableOpacity
                      onPress={sendOTP}
                      disabled={loading}
                      activeOpacity={0.85}
                    >
                      <LinearGradient
                        colors={loading ? ['#94a3b8', '#94a3b8'] : ['#ff6b35', '#ff4517']}
                        start={{ x: 0, y: 0 }}
                        end={{ x: 1, y: 0 }}
                        style={styles.modernButton}
                      >
                        {loading ? (
                          <ActivityIndicator color="#fff" size="small" />
                        ) : (
                          <>
                            <Text style={styles.buttonText}>Send OTP</Text>
                            <Ionicons name="arrow-forward" size={20} color="#fff" />
                          </>
                        )}
                      </LinearGradient>
                    </TouchableOpacity>
                  </Animated.View>
                </>
              ) : (
                <>
                  {/* Back Button */}
                  <TouchableOpacity
                    style={styles.backButton}
                    onPress={() => setStep('mobile')}
                  >
                    <Ionicons name="arrow-back" size={20} color="#64748b" />
                    <Text style={styles.backText}>Change Number</Text>
                  </TouchableOpacity>

                  {/* OTP Input */}
                  <View style={styles.inputGroup}>
                    <Text style={styles.inputLabel}>Enter OTP</Text>
                    <View style={styles.otpInputContainer}>
                      <TextInput
                        style={styles.otpInput}
                        placeholder="••••••"
                        placeholderTextColor="#cbd5e1"
                        keyboardType="number-pad"
                        maxLength={6}
                        value={otp}
                        onChangeText={setOtp}
                        textAlign="center"
                      />
                    </View>
                  </View>

                  {/* Verify Button */}
                  <Animated.View style={{ transform: [{ scale: pulseAnim }] }}>
                    <TouchableOpacity
                      onPress={verifyOTP}
                      disabled={loading}
                      activeOpacity={0.85}
                    >
                      <LinearGradient
                        colors={loading ? ['#94a3b8', '#94a3b8'] : ['#10b981', '#059669']}
                        start={{ x: 0, y: 0 }}
                        end={{ x: 1, y: 0 }}
                        style={styles.modernButton}
                      >
                        {loading ? (
                          <ActivityIndicator color="#fff" size="small" />
                        ) : (
                          <>
                            <Text style={styles.buttonText}>Verify & Login</Text>
                            <Ionicons name="checkmark-circle" size={20} color="#fff" />
                          </>
                        )}
                      </LinearGradient>
                    </TouchableOpacity>
                  </Animated.View>

                  {/* Resend OTP */}
                  <TouchableOpacity
                    style={styles.resendButton}
                    onPress={sendOTP}
                    disabled={loading}
                  >
                    <Ionicons name="refresh" size={16} color="#ff6b35" />
                    <Text style={styles.resendText}>Resend OTP</Text>
                  </TouchableOpacity>
                </>
              )}

              {/* Stats Section */}
              <View style={styles.statsContainer}>
                <View style={styles.statItem}>
                  <Ionicons name="people" size={16} color="#ff6b35" />
                  <Text style={styles.statText}>10L+ Users</Text>
                </View>
                <View style={styles.statDivider} />
                <View style={styles.statItem}>
                  <Ionicons name="star" size={16} color="#fbbf24" />
                  <Text style={styles.statText}>4.8 Rating</Text>
                </View>
                <View style={styles.statDivider} />
                <View style={styles.statItem}>
                  <Ionicons name="flash" size={16} color="#10b981" />
                  <Text style={styles.statText}>Instant</Text>
                </View>
              </View>
            </LinearGradient>
          </Animated.View>

          {/* Demo Info */}
          <View style={styles.demoInfo}>
            <Ionicons name="information-circle-outline" size={16} color="#64748b" />
            <Text style={styles.demoText}>Demo: 8888888888 / OTP: 123456</Text>
          </View>

          {/* Footer Links */}
          <View style={styles.footerLinks}>
            <TouchableOpacity>
              <Text style={styles.linkText}>Terms</Text>
            </TouchableOpacity>
            <Text style={styles.linkDivider}>•</Text>
            <TouchableOpacity>
              <Text style={styles.linkText}>Privacy</Text>
            </TouchableOpacity>
            <Text style={styles.linkDivider}>•</Text>
            <TouchableOpacity>
              <Text style={styles.linkText}>Support</Text>
            </TouchableOpacity>
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  decorCircle: {
    position: 'absolute',
    borderRadius: 1000,
  },
  decorCircle1: {
    width: 300,
    height: 300,
    top: -100,
    right: -100,
    backgroundColor: 'rgba(255,107,53,0.08)',
  },
  decorCircle2: {
    width: 200,
    height: 200,
    bottom: 100,
    left: -50,
    backgroundColor: 'rgba(99,102,241,0.08)',
  },
  decorCircle3: {
    width: 150,
    height: 150,
    top: SCREEN_HEIGHT * 0.4,
    right: -30,
    backgroundColor: 'rgba(16,185,129,0.08)',
  },
  scrollContent: {
    flexGrow: 1,
    paddingHorizontal: 24,
    paddingTop: 60,
    paddingBottom: Platform.OS === 'ios' ? 60 : 50,
  },
  logoSection: {
    alignItems: 'center',
    marginBottom: 40,
  },
  logoGlowContainer: {
    position: 'relative',
    marginBottom: 20,
  },
  logoGlow: {
    position: 'absolute',
    width: 140,
    height: 140,
    borderRadius: 40,
    backgroundColor: 'rgba(255,107,53,0.3)',
    top: -10,
    left: -10,
    zIndex: -1,
  },
  logoGradientBg: {
    width: 120,
    height: 120,
    borderRadius: 30,
    alignItems: 'center',
    justifyContent: 'center',
    ...Platform.select({
      ios: {
        shadowColor: '#ff6b35',
        shadowOffset: { width: 0, height: 8 },
        shadowOpacity: 0.3,
        shadowRadius: 20,
      },
      android: {
        elevation: 8,
      },
    }),
  },
  logoImage: {
    width: 70,
    height: 70,
    tintColor: '#fff',
  },
  appTitle: {
    fontSize: 36,
    fontWeight: '800',
    color: '#0f172a',
    marginBottom: 6,
    letterSpacing: -0.5,
  },
  appTagline: {
    fontSize: 16,
    color: '#64748b',
    fontWeight: '500',
    marginBottom: 24,
  },
  trustBadges: {
    flexDirection: 'row',
    gap: 12,
    marginTop: 4,
  },
  badge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    backgroundColor: '#fff',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 20,
    ...Platform.select({
      ios: {
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 2 },
        shadowOpacity: 0.1,
        shadowRadius: 8,
      },
      android: {
        elevation: 2,
      },
    }),
  },
  badgeText: {
    fontSize: 11,
    color: '#475569',
    fontWeight: '600',
  },
  formCard: {
    borderRadius: 32,
    overflow: 'hidden',
    marginBottom: 24,
    ...Platform.select({
      ios: {
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 12 },
        shadowOpacity: 0.12,
        shadowRadius: 24,
      },
      android: {
        elevation: 8,
      },
    }),
  },
  formGradient: {
    padding: 28,
  },
  formHeader: {
    marginBottom: 28,
  },
  formTitle: {
    fontSize: 24,
    fontWeight: '700',
    color: '#0f172a',
    marginBottom: 8,
  },
  formSubtitle: {
    fontSize: 14,
    color: '#64748b',
    lineHeight: 20,
  },
  inputGroup: {
    marginBottom: 24,
  },
  inputLabel: {
    fontSize: 13,
    fontWeight: '600',
    color: '#475569',
    marginBottom: 10,
    marginLeft: 4,
  },
  modernInputContainer: {
    flexDirection: 'row',
    backgroundColor: '#f8fafc',
    borderRadius: 16,
    borderWidth: 2,
    borderColor: '#e2e8f0',
    overflow: 'hidden',
  },
  countryCodeBox: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    paddingHorizontal: 16,
    backgroundColor: '#fff',
  },
  flagIcon: {
    width: 24,
    height: 16,
    borderRadius: 2,
  },
  countryCodeText: {
    fontSize: 16,
    fontWeight: '600',
    color: '#0f172a',
  },
  inputDivider: {
    width: 1,
    backgroundColor: '#e2e8f0',
  },
  modernInput: {
    flex: 1,
    fontSize: 16,
    color: '#0f172a',
    paddingHorizontal: 16,
    paddingVertical: 16,
    fontWeight: '500',
  },
  otpInputContainer: {
    backgroundColor: '#f8fafc',
    borderRadius: 16,
    borderWidth: 2,
    borderColor: '#e2e8f0',
  },
  otpInput: {
    fontSize: 32,
    fontWeight: '700',
    color: '#0f172a',
    paddingVertical: 20,
    letterSpacing: 12,
  },
  modernButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    paddingVertical: 18,
    borderRadius: 16,
    ...Platform.select({
      ios: {
        shadowColor: '#ff6b35',
        shadowOffset: { width: 0, height: 4 },
        shadowOpacity: 0.3,
        shadowRadius: 12,
      },
      android: {
        elevation: 6,
      },
    }),
  },
  buttonText: {
    fontSize: 16,
    fontWeight: '700',
    color: '#fff',
  },
  backButton: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    alignSelf: 'flex-start',
    marginBottom: 20,
  },
  backText: {
    fontSize: 14,
    color: '#64748b',
    fontWeight: '600',
  },
  resendButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 6,
    marginTop: 16,
    paddingVertical: 12,
  },
  resendText: {
    fontSize: 14,
    fontWeight: '600',
    color: '#ff6b35',
  },
  statsContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: 24,
    paddingTop: 24,
    borderTopWidth: 1,
    borderTopColor: '#e2e8f0',
  },
  statItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  statText: {
    fontSize: 12,
    color: '#64748b',
    fontWeight: '600',
  },
  statDivider: {
    width: 1,
    height: 16,
    backgroundColor: '#e2e8f0',
    marginHorizontal: 16,
  },
  demoInfo: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 6,
    backgroundColor: 'rgba(100, 116, 139, 0.08)',
    paddingVertical: 12,
    paddingHorizontal: 16,
    borderRadius: 12,
    marginBottom: 16,
  },
  demoText: {
    fontSize: 12,
    color: '#64748b',
    fontWeight: '500',
  },
  footerLinks: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 12,
  },
  linkText: {
    fontSize: 13,
    color: '#64748b',
    fontWeight: '500',
  },
  linkDivider: {
    fontSize: 13,
    color: '#cbd5e1',
  },
});
