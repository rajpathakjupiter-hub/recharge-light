import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  FlatList,
  TouchableOpacity,
  ActivityIndicator,
  Image,
  Platform,
  RefreshControl,
  TextInput,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { router } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import AsyncStorage from '@react-native-async-storage/async-storage';
import axios from 'axios';

const BACKEND_URL = process.env.EXPO_PUBLIC_BACKEND_URL || '';

interface Brand {
  id: string;
  title: string;
  category: string;
  denomination_type: string;
  min_amount?: number;
  max_amount?: number;
  denominations?: string;
  commission_percent: number;
  thumbnail_url?: string;
  logo_url?: string;
}

export default function GiftCardsScreen() {
  const [brands, setBrands] = useState<Brand[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [failedImages, setFailedImages] = useState<Set<string>>(new Set());

  const getAuthHeader = async () => {
    const token = await AsyncStorage.getItem('auth_token');
    return { Authorization: `Bearer ${token}` };
  };

  const fetchBrands = async () => {
    try {
      const headers = await getAuthHeader();
      const response = await axios.get(`${BACKEND_URL}/api/giftcards/brands`, { headers });
      if (response.data?.brands) {
        setBrands(response.data.brands);
      }
    } catch (error: any) {
      console.error('Fetch brands error:', error);
      if (error.response?.status === 401) {
        await AsyncStorage.clear();
        router.replace('/login');
      }
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchBrands();
  }, []);

  const onRefresh = async () => {
    setRefreshing(true);
    setFailedImages(new Set());
    await fetchBrands();
    setRefreshing(false);
  };

  const filtered = brands.filter((b) => {
    if (!searchQuery) return true;
    return b.title.toLowerCase().includes(searchQuery.toLowerCase());
  });

  const getBrandColor = (title: string) => {
    const hash = title.split('').reduce((a, b) => { a = ((a << 5) - a) + b.charCodeAt(0); return a & a; }, 0);
    const colors = ['#f08a5d', '#6366f1', '#22c55e', '#3b82f6', '#a855f7', '#ec4899', '#f59e0b', '#14b8a6'];
    return colors[Math.abs(hash) % colors.length];
  };

  const handleImageError = (brandId: string) => {
    setFailedImages(prev => new Set(prev).add(brandId));
  };

  const renderBrand = ({ item }: { item: Brand }) => {
    const color = getBrandColor(item.title);
    const showLogo = item.logo_url && !failedImages.has(item.id);

    let denomStr = '';
    if ((item.denomination_type === 'FIXED' || item.denomination_type === 'fixed') && item.denominations) {
      try {
        const parsed = JSON.parse(item.denominations.replace(/'/g, '"'));
        denomStr = parsed.map((d: number) => `₹${d}`).join(', ');
      } catch {
        const nums = item.denominations.replace(/[\[\]]/g, '').split(',').map((s: string) => s.trim()).filter(Boolean);
        denomStr = nums.map((n: string) => `₹${n}`).join(', ');
      }
    }

    return (
      <TouchableOpacity
        style={styles.brandCard}
        onPress={() =>
          router.push({
            pathname: '/giftcard-purchase',
            params: {
              brand_id: item.id,
              brand_name: item.title,
              min_amount: item.min_amount?.toString() || '500',
              max_amount: item.max_amount?.toString() || '10000',
              denomination_type: item.denomination_type,
              denominations: item.denominations || '',
              commission_percent: item.commission_percent.toString(),
              category: item.category,
            },
          })
        }
        activeOpacity={0.7}
      >
        {showLogo ? (
          <Image
            source={{ uri: item.logo_url }}
            style={styles.brandLogo}
            resizeMode="cover"
            onError={() => handleImageError(item.id)}
          />
        ) : (
          <View style={[styles.brandIconFallback, { backgroundColor: `${color}18` }]}>
            <Text style={[styles.brandInitial, { color }]}>
              {item.title.charAt(0).toUpperCase()}
            </Text>
          </View>
        )}
        <View style={styles.brandInfo}>
          <Text style={styles.brandName} numberOfLines={1}>{item.title}</Text>
          {denomStr ? (
            <Text style={styles.brandAmount} numberOfLines={1}>{denomStr}</Text>
          ) : (
            <Text style={styles.brandAmount}>₹{item.min_amount} - ₹{item.max_amount}</Text>
          )}
        </View>
        <View style={styles.brandRight}>
          <Text style={styles.commPercent}>{item.commission_percent}%</Text>
          <Ionicons name="chevron-forward" size={16} color="#ddd" />
        </View>
      </TouchableOpacity>
    );
  };

  return (
    <SafeAreaView style={styles.container}>
      {/* Header */}
      <View style={styles.header}>
        <TouchableOpacity style={styles.backButton} onPress={() => router.back()}>
          <Ionicons name="arrow-back" size={24} color="#1a1a2e" />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Gift Cards</Text>
        <TouchableOpacity
          style={styles.historyBtn}
          onPress={() => router.push('/giftcard-history')}
        >
          <Ionicons name="receipt-outline" size={20} color="#f08a5d" />
        </TouchableOpacity>
      </View>

      {/* Search Bar */}
      <View style={styles.searchContainer}>
        <Ionicons name="search" size={20} color="#aaa" />
        <TextInput
          style={styles.searchInput}
          placeholder="Search gift cards..."
          placeholderTextColor="#bbb"
          value={searchQuery}
          onChangeText={setSearchQuery}
        />
        {searchQuery ? (
          <TouchableOpacity onPress={() => setSearchQuery('')}>
            <Ionicons name="close-circle" size={20} color="#ccc" />
          </TouchableOpacity>
        ) : null}
      </View>

      {loading ? (
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color="#f08a5d" />
          <Text style={styles.loadingText}>Loading gift cards...</Text>
        </View>
      ) : (
        <FlatList
          data={filtered}
          renderItem={renderBrand}
          keyExtractor={(item) => item.id}
          contentContainerStyle={styles.listContent}
          showsVerticalScrollIndicator={false}
          refreshControl={
            <RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor="#f08a5d" />
          }
          ListEmptyComponent={
            <View style={styles.emptyContainer}>
              <Ionicons name="gift-outline" size={56} color="#ccc" />
              <Text style={styles.emptyText}>
                {searchQuery ? 'No gift cards found' : 'No gift cards available'}
              </Text>
            </View>
          }
          ListHeaderComponent={
            <Text style={styles.resultCount}>{filtered.length} gift cards</Text>
          }
        />
      )}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f7fa',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingVertical: 10,
    backgroundColor: '#fff',
  },
  backButton: {
    width: 40,
    height: 40,
    borderRadius: 12,
    alignItems: 'center',
    justifyContent: 'center',
  },
  headerTitle: {
    flex: 1,
    fontSize: 20,
    fontWeight: '700',
    color: '#1a1a2e',
    textAlign: 'center',
  },
  historyBtn: {
    width: 40,
    height: 40,
    borderRadius: 12,
    backgroundColor: 'rgba(240,138,93,0.1)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  searchContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#fff',
    marginHorizontal: 16,
    marginTop: 8,
    marginBottom: 4,
    borderRadius: 14,
    paddingHorizontal: 14,
    paddingVertical: 10,
    borderWidth: 1,
    borderColor: '#f0f0f0',
  },
  searchInput: {
    flex: 1,
    fontSize: 15,
    color: '#1a1a2e',
    marginLeft: 10,
    paddingVertical: 2,
  },
  loadingContainer: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    gap: 12,
  },
  loadingText: {
    fontSize: 14,
    color: '#888',
  },
  resultCount: {
    fontSize: 12,
    color: '#aaa',
    marginBottom: 10,
  },
  listContent: {
    padding: 16,
    paddingTop: 8,
  },
  brandCard: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#fff',
    borderRadius: 14,
    padding: 12,
    marginBottom: 10,
    ...Platform.select({
      ios: {
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 2 },
        shadowOpacity: 0.05,
        shadowRadius: 10,
      },
      android: { elevation: 2 },
    }),
  },
  brandLogo: {
    width: 48,
    height: 48,
    borderRadius: 12,
    backgroundColor: '#f5f5f5',
  },
  brandIconFallback: {
    width: 48,
    height: 48,
    borderRadius: 12,
    alignItems: 'center',
    justifyContent: 'center',
  },
  brandInitial: {
    fontSize: 20,
    fontWeight: 'bold',
  },
  brandInfo: {
    flex: 1,
    marginLeft: 12,
  },
  brandName: {
    fontSize: 14,
    fontWeight: '700',
    color: '#1a1a2e',
    marginBottom: 3,
  },
  brandAmount: {
    fontSize: 12,
    color: '#888',
  },
  brandRight: {
    alignItems: 'flex-end',
    gap: 4,
    marginLeft: 8,
  },
  commPercent: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#22c55e',
  },
  emptyContainer: {
    alignItems: 'center',
    paddingVertical: 60,
    gap: 12,
  },
  emptyText: {
    fontSize: 14,
    color: '#999',
  },
});
