import React, { useEffect, useRef, useState } from 'react';
import {
  View, Text, StyleSheet, TouchableOpacity, Animated, Platform,
  Share, ActivityIndicator, Alert,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { router, useLocalSearchParams } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';
import AsyncStorage from '@react-native-async-storage/async-storage';
import axios from 'axios';
import * as Clipboard from 'expo-clipboard';

const BACKEND_URL = process.env.EXPO_PUBLIC_BACKEND_URL || '';

export default function GiftCardStatusScreen() {
  const params = useLocalSearchParams();
  const status = (params.status as string) || 'pending';
  const orderId = (params.order_id as string) || '';
  const amount = (params.amount as string) || '0';
  const brandName = (params.brand_name as string) || '';
  const commission = (params.commission as string) || '0';
  const message = (params.message as string) || '';

  const [voucherCode, setVoucherCode] = useState((params.voucher_code as string) || '');
  const [voucherPin, setVoucherPin] = useState((params.voucher_pin as string) || '');
  const [expiryDate, setExpiryDate] = useState((params.expiry_date as string) || '');
  const [loadingVoucher, setLoadingVoucher] = useState(false);
  const [actualStatus, setActualStatus] = useState(status);
  const [copiedField, setCopiedField] = useState('');

  const scaleAnim = useRef(new Animated.Value(0)).current;
  const fadeAnim = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    Animated.sequence([
      Animated.spring(scaleAnim, { toValue: 1, useNativeDriver: true, tension: 50, friction: 6 }),
      Animated.timing(fadeAnim, { toValue: 1, duration: 400, useNativeDriver: true }),
    ]).start();

    // If purchase was success but no voucher details, fetch from history
    if ((status === 'success' || status === 'pending') && !voucherCode && !voucherPin) {
      fetchVoucherFromHistory();
    }
  }, []);

  const fetchVoucherFromHistory = async () => {
    setLoadingVoucher(true);
    try {
      const token = await AsyncStorage.getItem('auth_token');
      const headers = { Authorization: `Bearer ${token}` };
      await new Promise(r => setTimeout(r, 2000));

      const response = await axios.get(`${BACKEND_URL}/api/giftcards/history?limit=5`, { headers });
      if (response.data?.orders?.length > 0) {
        const amtNum = parseInt(amount);
        const matching = response.data.orders.find(
          (o: any) => o.amount === amtNum && o.status === 'success'
        );
        if (matching) {
          if (matching.voucher_code) setVoucherCode(matching.voucher_code);
          if (matching.voucher_pin) setVoucherPin(matching.voucher_pin);
          if (matching.expiry_date) setExpiryDate(matching.expiry_date);
          setActualStatus('success');
        }
      }
    } catch (e) { console.error(e); }
    finally { setLoadingVoucher(false); }
  };

  const copyToClipboard = async (text: string, field: string) => {
    try {
      await Clipboard.setStringAsync(text);
      setCopiedField(field);
      setTimeout(() => setCopiedField(''), 2000);
    } catch {
      Alert.alert('Copied', text);
    }
  };

  const isSuccess = actualStatus === 'success';
  const isFailed = actualStatus === 'failed' || actualStatus === 'error';
  const statusColor = isSuccess ? '#22c55e' : isFailed ? '#ef4444' : '#f08a5d';
  const statusIcon = isSuccess ? 'checkmark-circle' : isFailed ? 'close-circle' : 'time';
  const statusTitle = isSuccess ? 'Purchase Successful!' : isFailed ? 'Purchase Failed' : 'Processing...';

  const handleShare = async () => {
    let msg = `Gift Card: ${brandName}\nAmount: ₹${amount}`;
    if (orderId) msg += `\nOrder: ${orderId}`;
    if (voucherCode) msg += `\nVoucher Code: ${voucherCode}`;
    if (voucherPin) msg += `\nVoucher PIN: ${voucherPin}`;
    if (expiryDate) msg += `\nExpiry: ${expiryDate}`;
    try { await Share.share({ message: msg }); } catch {}
  };

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.content}>
        {/* Status Icon */}
        <Animated.View style={[styles.iconBox, { backgroundColor: `${statusColor}15`, transform: [{ scale: scaleAnim }] }]}>
          <Ionicons name={statusIcon as any} size={64} color={statusColor} />
        </Animated.View>

        <Text style={[styles.statusTitle, { color: statusColor }]}>{statusTitle}</Text>
        {message && !isSuccess ? <Text style={styles.statusMsg}>{message}</Text> : null}

        {/* Details Card */}
        <Animated.View style={[styles.card, { opacity: fadeAnim }]}>
          <DetailRow label="Gift Card" value={brandName} />
          <DetailRow label="Amount" value={`₹${amount}`} />
          {orderId ? <DetailRow label="Order ID" value={orderId} small /> : null}
          {isSuccess && parseFloat(commission) > 0 ? (
            <DetailRow label="Commission" value={`+₹${commission}`} valueColor="#22c55e" />
          ) : null}

          {/* Voucher Loading */}
          {loadingVoucher && !voucherCode && !voucherPin && (
            <View style={styles.voucherLoading}>
              <ActivityIndicator size="small" color="#6366f1" />
              <Text style={styles.voucherLoadingText}>Fetching voucher details...</Text>
            </View>
          )}

          {/* Voucher Details */}
          {(voucherCode || voucherPin) ? (
            <View style={styles.voucherSection}>
              <LinearGradient colors={['#6366f1', '#8b5cf6']} style={styles.voucherCard}>
                <Ionicons name="gift" size={22} color="#fff" />

                {voucherCode ? (
                  <View style={styles.voucherRow}>
                    <Text style={styles.voucherLabel}>Voucher Code</Text>
                    <View style={styles.voucherValueRow}>
                      <Text style={styles.voucherValue}>{voucherCode}</Text>
                      <TouchableOpacity style={styles.copyBtn} onPress={() => copyToClipboard(voucherCode, 'code')}>
                        <Ionicons name={copiedField === 'code' ? 'checkmark' : 'copy-outline'} size={16} color="#fff" />
                        <Text style={styles.copyText}>{copiedField === 'code' ? 'Copied!' : 'Copy'}</Text>
                      </TouchableOpacity>
                    </View>
                  </View>
                ) : null}

                {voucherPin ? (
                  <View style={styles.voucherRow}>
                    <Text style={styles.voucherLabel}>Voucher PIN</Text>
                    <View style={styles.voucherValueRow}>
                      <Text style={styles.voucherValue}>{voucherPin}</Text>
                      <TouchableOpacity style={styles.copyBtn} onPress={() => copyToClipboard(voucherPin, 'pin')}>
                        <Ionicons name={copiedField === 'pin' ? 'checkmark' : 'copy-outline'} size={16} color="#fff" />
                        <Text style={styles.copyText}>{copiedField === 'pin' ? 'Copied!' : 'Copy'}</Text>
                      </TouchableOpacity>
                    </View>
                  </View>
                ) : null}

                {expiryDate ? (
                  <View style={styles.voucherRow}>
                    <Text style={styles.voucherLabel}>Expiry Date</Text>
                    <Text style={styles.voucherExpiry}>{expiryDate}</Text>
                  </View>
                ) : null}
              </LinearGradient>
            </View>
          ) : isSuccess && !loadingVoucher ? (
            <View style={styles.voucherNote}>
              <Ionicons name="information-circle" size={16} color="#f08a5d" />
              <Text style={styles.voucherNoteText}>Voucher details will appear in Gift Card History</Text>
            </View>
          ) : null}
        </Animated.View>

        {/* Actions */}
        <View style={styles.actions}>
          {isSuccess && (
            <TouchableOpacity style={styles.shareBtn} onPress={handleShare}>
              <Ionicons name="share-outline" size={20} color="#6366f1" />
              <Text style={styles.shareBtnText}>Share Details</Text>
            </TouchableOpacity>
          )}

          <TouchableOpacity style={styles.homeBtn} onPress={() => router.replace('/(tabs)')} activeOpacity={0.8}>
            <LinearGradient colors={['#f08a5d', '#e67e4a']} style={styles.homeBtnInner}>
              <Ionicons name="home" size={20} color="#fff" />
              <Text style={styles.homeBtnText}>Go Home</Text>
            </LinearGradient>
          </TouchableOpacity>

          {isSuccess && (
            <TouchableOpacity style={styles.historyLink} onPress={() => router.push('/giftcard-history')}>
              <Text style={styles.historyLinkText}>View Gift Card History</Text>
            </TouchableOpacity>
          )}
          {isFailed && (
            <TouchableOpacity style={styles.retryBtn} onPress={() => router.back()}>
              <Text style={styles.retryBtnText}>Try Again</Text>
            </TouchableOpacity>
          )}
        </View>
      </View>
    </SafeAreaView>
  );
}

function DetailRow({ label, value, small, valueColor }: { label: string; value: string; small?: boolean; valueColor?: string }) {
  return (
    <View style={drStyles.row}>
      <Text style={drStyles.label}>{label}</Text>
      <Text style={[small ? drStyles.valueSmall : drStyles.value, valueColor ? { color: valueColor } : null]} numberOfLines={1}>{value}</Text>
    </View>
  );
}

const drStyles = StyleSheet.create({
  row: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingVertical: 11, borderBottomWidth: 1, borderBottomColor: '#f5f5f5' },
  label: { fontSize: 13, color: '#888' },
  value: { fontSize: 15, fontWeight: '700', color: '#1a1a2e' },
  valueSmall: { fontSize: 11, fontWeight: '600', color: '#666', maxWidth: 180, textAlign: 'right' },
});

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#f5f7fa' },
  content: { flex: 1, alignItems: 'center', justifyContent: 'center', padding: 20 },
  iconBox: { width: 120, height: 120, borderRadius: 60, alignItems: 'center', justifyContent: 'center', marginBottom: 16 },
  statusTitle: { fontSize: 22, fontWeight: 'bold', marginBottom: 6 },
  statusMsg: { fontSize: 13, color: '#888', textAlign: 'center', marginBottom: 20, paddingHorizontal: 16 },
  card: {
    width: '100%', backgroundColor: '#fff', borderRadius: 20, padding: 18, marginBottom: 20,
    ...Platform.select({ ios: { shadowColor: '#000', shadowOffset: { width: 0, height: 4 }, shadowOpacity: 0.08, shadowRadius: 16 }, android: { elevation: 4 } }),
  },
  voucherLoading: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 10, paddingVertical: 14 },
  voucherLoadingText: { fontSize: 13, color: '#6366f1' },
  voucherSection: { marginTop: 14 },
  voucherCard: { borderRadius: 16, padding: 18, alignItems: 'center', gap: 4 },
  voucherRow: { width: '100%', marginTop: 10 },
  voucherLabel: { fontSize: 11, color: 'rgba(255,255,255,0.6)', marginBottom: 4 },
  voucherValueRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  voucherValue: { fontSize: 20, fontWeight: 'bold', color: '#fff', letterSpacing: 2, flex: 1 },
  copyBtn: { flexDirection: 'row', alignItems: 'center', gap: 4, backgroundColor: 'rgba(255,255,255,0.2)', borderRadius: 8, paddingHorizontal: 10, paddingVertical: 6 },
  copyText: { fontSize: 11, fontWeight: '600', color: '#fff' },
  voucherExpiry: { fontSize: 15, fontWeight: '600', color: '#fff' },
  voucherNote: { flexDirection: 'row', alignItems: 'center', gap: 8, paddingVertical: 12, paddingHorizontal: 12, backgroundColor: '#fff8f3', borderRadius: 10, marginTop: 12 },
  voucherNoteText: { fontSize: 12, color: '#f08a5d', flex: 1 },
  actions: { width: '100%', gap: 10 },
  shareBtn: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8, paddingVertical: 14, borderRadius: 14, backgroundColor: '#fff', borderWidth: 1, borderColor: '#6366f1' },
  shareBtnText: { fontSize: 15, fontWeight: '600', color: '#6366f1' },
  homeBtn: { borderRadius: 14, overflow: 'hidden' },
  homeBtnInner: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', paddingVertical: 15, gap: 8 },
  homeBtnText: { fontSize: 16, fontWeight: '700', color: '#fff' },
  historyLink: { alignItems: 'center', paddingVertical: 8 },
  historyLinkText: { fontSize: 14, fontWeight: '600', color: '#6366f1', textDecorationLine: 'underline' },
  retryBtn: { alignItems: 'center', paddingVertical: 12 },
  retryBtnText: { fontSize: 15, fontWeight: '600', color: '#f08a5d' },
});
